<!DOCTYPE html>

<html>

<head>
    <title>Customer Mail </title>
</head>

<body>

    <p> Dear <?php echo e($fromName); ?>,</p>

   <p>We appreciate your interest in CivitBUILD, our specialized Construction ERP Software.</p>

<p><strong>Our Client Success Manager will be reaching out to you very soon.</strong></p>

<p><strong>Meanwhile, know more about our specialized CivitBUILD solutions:</strong></p>

<p><a href="https://thecivit.com/software-for-builders-developers/">Construction Operations for Builders & Developers</a><br>

<a href="https://thecivit.com/construction-management-software-for-contractors/">Bidding and Project Management for Contractors</a></p>

    
    Warm Regards,<br>
    CivitBUILD<br>
    Phone: +97 15 0383 4122<br>
    measales@thecivit.com
    
    

</body>
</html><?php /**PATH /home4/saletc4y/test.credtify.com/resources/views/email-body/email-enquiry2.blade.php ENDPATH**/ ?>

<?php $__env->startSection('admindashboard'); ?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Default Card Example -->
                <div class="card mb-4">
                    <div class="card-header">
                        INFORMATION
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Name:</td>

                                    <td><?php echo e($enquire->fName . ' ' . $enquire->lName); ?></td>
                                </tr>
                            
                                <tr>
                                    <td>Phone Number:</td>

                                    <td><?php echo e($enquire->phone); ?></td>
                                </tr>
                                <tr>
                                    <td>Email ID:</td>

                                    <td><?php echo e($enquire->email); ?></td>
                                </tr>
                                <tr>
                                    <td>Designation:</td>

                                    <td><?php echo e($enquire->designation); ?></td>
                                </tr>
                                
                                <tr>
                                    <td>Company Name:</td>

                                    <td><?php echo e($enquire->companyName); ?></td>
                                </tr>
                                <tr>
                                    <td>Website:</td>

                                    <td><?php echo e($enquire->companyWebsite); ?></td>
                                </tr>
                                <tr>
                                    <td>Company Type:</td>

                                    <td><?php echo e($enquire->companyType); ?></td>
                                </tr>
                                <tr>
                                    <td>Country:</td>

                                    <td><?php echo e($enquire->country); ?></td>
                                </tr>
                                <tr>
                                    <td>City:</td>

                                    <td><?php echo e($enquire->city); ?></td>
                                </tr>
                                <tr>
                                    <td>About Project:</td>

                                    <td><?php echo e($enquire->aboutProject); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CivitBUILD\new-backup\resources\views/admin/enquires-views/enquiresview.blade.php ENDPATH**/ ?>
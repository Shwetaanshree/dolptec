<!DOCTYPE html>
<html lang="en">


<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="Purpose-built Integrated Construction Project Management Software For Builders, Contractors and Owners | CivitBuild - Construction ERP Software">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- ========== Page Title ========== -->
    <title>Construction Project Management Software For Owners, Builders and Contractors</title>

    <base href="<?php echo e(asset('public')); ?>/">

    <!-- ========== Favicon Icon ========== -->
    <!-- <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon"> -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/favicon_io/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/favicon_io/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/favicon_io/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/favicon_io/site.webmanifest')); ?>">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/elegant-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/flaticon-set.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/bootsnav.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" />

    <!-- <link href="<?php echo e(asset('assets/css/demo.css')); ?>" rel="stylesheet" /> -->
    <link href="<?php echo e(asset('assets/css/intlTelInput.css')); ?>" rel="stylesheet" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />


    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.css"> -->

    <!-- ========== End Stylesheet ========== -->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">

    <script type="text/javascript">
    function callbackThen(response) {
        // read Promise object
        response.json().then(function(data) {
            console.log(data);
            if (data.success && data.score > 0.5) {
                console.log('valid recpatcha');
            } else {
                document.getElementById('home-enquire-form').addEventListener('submit', function(event) {
                    event.preventDefault();
                    alert('recpatcha error');
                });

                document.getElementById('modal-enquire-form').addEventListener('submit', function(event) {
                    event.preventDefault();
                    alert('recpatcha error');
                });
            }
        });
    }

    function callbackCatch(error) {
        console.error('Error:', error)
    }
    </script>

    <?php echo htmlScriptTagJsApi([
    'callback_then' => 'callbackThen',
    'callback_catch' => 'callbackCatch',
    ]); ?>


    <style>
    .demo {
        /* background: linear-gradient(to right ,#f33963 ,#ff735b); */
        /* background: linear-gradient(to right ,#0070bc ,#0070bc); */
        background: linear-gradient(to right, #0070bc3b, #0070bc9c);
    }

    .top-icon,
    .bottom-icon {
        display: block;
        font-size: 70px;
        color: #fdfeff;
        text-align: center;
        margin: 0 auto;
    }

    .testimonial {
        padding: 0 40px;
        position: relative;
        overflow: hidden;
        /* background: linear-gradient(to right ,#ff735b ,#f33963); */
        background: linear-gradient(to right, #0070bc, #00ba50);
        color: #fdfeff;
        z-index: 1;
    }

    .testimonial:after {
        content: "";
        width: 150px;
        height: 107%;
        background: #00ba5099;
        position: absolute;
        top: -20px;
        left: -60px;
        transform: matrix(1, 0, 0.5, 1, 150, 0);
        z-index: -1;
    }

    .testimonial .pic {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        overflow: hidden;
        float: left;
        margin: 10px 25px 0 0;
        position: relative;
    }

    .testimonial .pic img {
        width: 100%;
        height: auto;
    }

    .testimonial .testimonial-content {
        width: 100%;
        height: 250px;
        float: right;
        padding: 30px 0;
    }

    .testimonial .testimonial-title {
        font-size: 20px;
        font-weight: 900;
        margin: 0 0 20px;
        text-transform: capitalize;
    }

    .testimonial .description {
        font-size: 14px;
        line-height: 26px;
    }

    .owl-theme .owl-controls .owl-page span {
        width: 10px;
        height: 10px;
        background: #fff;
        border: 2px solid #1ec4f3;
    }

    .owl-theme .owl-controls .owl-page:active span {
        color: #1ec4f3;
    }

    @media only screen and (max-width: 767px) {
        .testimonial {
            text-align: center;
        }

        .testimonial .pic {
            float: none;
            margin: 20px auto 0;
        }

        .testimonial .testimonial-content {
            width: 100%;
            height: 800px;
            float: none;
            padding: 20px 0;
        }

        .testimonial .description {
            font-size: 14px;
        }
    }

    @media only screen and (max-width: 480px) {
        .testimonial {
            padding: 0 20px;
        }

        .testimonial .testimonial-title {
            font-size: 22px;
        }
    }

    .error-message {
        color: red;
    }
    </style>
</head>

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Header 
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-fixed dark no-background bootsnav">

            <div class="container-fill">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav button">
                    <ul>
                        <li>
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal">Enquire
                                Now</a>
                            <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                                Open modal
                            </button> -->
                        </li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->



                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="/">
                        <img src="<?php echo e(asset('assets/img/logo2.png')); ?>" class="logo logo-display" alt="Logo">
                        <img src="<?php echo e(asset('assets/img/logo2.png')); ?>" class="logo logo-scrolled" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="#" data-out="#">
                        <li class="dropdown dropdown-right">
                            <a href="#home" class="smooth-menu">Home</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#Features">Features</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#Who-use-CivitBUILD">Who use CivitBUILD</a>
                        </li>

                        <li>
                            <a class="smooth-menu" href="#Why-CivitBUILD">Why CivitBUILD</a>
                        </li>

                        <li>
                            <a class="smooth-menu" href="#reviews">Reviews</a>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->

    <!-- Start Banner 
    ============================================= -->
    <div
        class="banner-area with-carousel bg-gray-responsive overflow-inherit content-double transparent-nav text-large">
        <!-- Fixed Shape -->
        <div class="fixed-shape" style="background-image: url(<?php echo e(asset('assets/img/shape/4.png')); ?>); height:100%;">
        </div>
        <!-- Fixed Shape -->
        <div class="box-table">
            <div class="box-cell">
                <div class="container">
                    <div class="double-items">
                        <div class="row align-center">
                            <div class="col-lg-6 left-info">
                                <div class="content wow fadeInLeft" data-wow-delay=".55s">
                                    <!-- <h1>We're building <span>software</span> for you</h1> -->
                                    <!-- <h1 class="banner-heading">#1 ERP Software For <span>Contractors</span> &
                                        <span>Construction</span> Industry
                                    </h1> -->
                                    <h1 class="banner-heading">Save <span>3X time</span> -
                                        Fastest Construction &amp; Contracting ERP Software</h1>

                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="box-shadow bg-white">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/save-time.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0; color:#0070bc;"><strong>Time saving
                                                            </strong></p>
                                                        <p style="margin:0;">3X faster project management</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="box-shadow bg-white">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/cubes.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0; color:#0070bc;"><strong>16+ Modules
                                                            </strong></p>
                                                        <p style="margin:0;">All project needs in one place</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row lg-pad">
                                        <div class="col-lg-6">
                                            <div class="box-shadow bg-white">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/customize.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0;color:#0070bc;"><strong>Customizable
                                                            </strong></p>
                                                        <p style="margin:0;">Customize CivitBUILD according to your
                                                            needs</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="box-shadow bg-white">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/ownership.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0; color:#0070bc;"><strong>Access From Anywhere
                                                            </strong></p>
                                                        <p style="margin:0;">Access Multiple sites from multiple devices
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="hero-form wow fadeInRight" data-wow-delay=".55s">
                                    <h3 class="text-white text-center" style="font-size:25px;">Book a Demo Now!</h3>
                                    <form action="<?php echo e(route('enquires')); ?>" method="POST" class="contact-form"
                                        id="modal-enquire-form">
                                        <?php echo csrf_field(); ?>


                                        <?php if(Session::has('error')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(Session::get('error')); ?>

                                        </div>
                                        <?php endif; ?>

                                        <?php if(Session::has('success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(Session::get('success')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="fName" name="fName"
                                                        placeholder="First Name" type="text" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="lName" name="lName"
                                                        placeholder="Last Name" type="text" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="email1" name="email"
                                                        placeholder="Corporate Email ID" type="text" required>
                                                    <span class="error-message" id="emailError1"></span>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" type="tel" id="phone1" name="phone"
                                                        placeholder="Phone Number">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="designation" name="designation"
                                                        placeholder="Designation" type="text" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <select class="form-control" id="companyType" name="companyType"
                                                        style="height: 50px;" required>
                                                        <option disabled="" selected="" value="">Select Company Type
                                                        </option>
                                                        <option value="General Contractor">General Contractor</option>
                                                        <option value="Specialty Contractor">Specialty Contractor
                                                        </option>
                                                        <option value="Owner or Developer">Owner or Developer</option>
                                                        <option value="Government">Government</option>
                                                        <option value="Other">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="companyName" name="companyName"
                                                        placeholder="Company Name" type="text" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="companyWebsite1"
                                                        name="companyWebsite" placeholder="Company Website" type="text"
                                                        required>
                                                    <span class="error-message" id="websiteError1"></span>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <span id="country-code1" style="display: none;"></span>
                                                    <input class="form-control" id="country-name1" name="country"
                                                        value="United Arab Emirates" placeholder="Country" type="text">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="city" name="city" placeholder="City"
                                                        type="text">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group comments">
                                                    <textarea class="form-control" id="aboutProject" name="aboutProject"
                                                        placeholder="Tell Us About Project"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-lg-12" style="text-align:center;">
                                                <button type="submit" name="submit" id="submit"
                                                    class="contact-form-button">
                                                    Get a Free Demo Now
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wavesshape">
                    <img src="<?php echo e(asset('assets/img/waves-shape.svg')); ?>" alt="Shape">
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->

    <!-- <div class="productSec bg-gray" style="padding:50px 0px;" id="Features">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2>CivitBUILD Contracting ERP Software Has it All</h2>
                        <p>Streamline business process by CivitBUILD contracting & construction ERP software</p>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="module-heading">
                        <h3 style="font-weight:600;">CivitBUILD ERP Core</h3>
                        <div class="hr-line"></div>
                    </div>
                    <div class="module-img">
                        <img src="<?php echo e(asset('assets/img/7053246.jpg')); ?>" />
                    </div>
                </div>
                <div class="col-lg-6"></div>
            </div>
        </div>
    </div> -->


    <div class="faq-area bg-gray default-padding-top2" style="background: url(<?php echo e(asset('assets/img/bg-features.png')); ?>);
    background-attachment: fixed;background-position: top;background-repeat: no-repeat;background-size: cover;"
        id="Features">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2><span>CivitBUILD Contracting ERP</span> Software Modules</h2>
                        <p>Streamline business process by CivitBUILD contracting & construction ERP software</p>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row wow fadeInRight" data-wow-delay=".15s">
                <div class="col-lg-6 thumb">
                    <h3 style="text-align:left;">CivitBUILD ERP Core</h3>
                    <div class="hr-line"></div>
                    <p style="padding-top:15px;">Whether you're aiming to broaden your horizons, reach new heights, or
                        simply shake things up, our solution is your key.</p>
                    <img src="<?php echo e(asset('assets/img/civitBuild-ERP-core.png')); ?>" alt="Thumb" style=" height: 300px;">
                </div>
                <div class="col-lg-6 faq-items default-padding-bottom">
                    <!-- Start Accordion -->
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne"
                                        aria-expanded="false" aria-controls="collapseOne">
                                        Financial Accounting
                                    </h4>
                                </div>

                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains global chart of accounts.</li>
                                                <li class="service-li-list">Supports multi-currency transactions.</li>
                                                <li class="service-li-list">Maintains customized cost centers.</li>
                                                <li class="service-li-list">Integrates with Subcontracting and
                                                    Procurement department for posting and payment of vendor invoices.
                                                </li>
                                                <li class="service-li-list">Integrates with Sales and Client Billing
                                                    department for Posting Invoices and payment receipts.</li>
                                                <li class="service-li-list">Provides Bank/ Cash - Payments/ Receipts,
                                                    Journal Vouchers, Debit Note, Credit Note, Bank Reconciliation,
                                                    Cheque Printing and Year End Finalization.</li>
                                                <li class="service-li-list">Provides project-wise MIS reports.</li>
                                                <li class="service-li-list">Integration with Tally.</li>
                                                <li class="service-li-list">Generates Project-wise Balance Sheet, Profit
                                                    & Loss and Trial Balance Reports.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo"
                                        aria-expanded="false" aria-controls="collapseTwo">
                                        Bid Management
                                    </h4>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <ul style="list-style-type:disc;">
                                            <li class="service-li-list">Create cost estimates for effective bidding
                                                for contract projects.
                                            </li>
                                            <li class="service-li-list">Provide excel template for importing client
                                                BOQ for quick
                                                preparation of estimate.</li>

                                            <li class="service-li-list">Supports multi-currency of the resources for
                                                preparing the estimate.
                                            </li>

                                            <li class="service-li-list">Provides Direct and Indirect cost estimate
                                                of the project during the
                                                bidding.</li>

                                            <li class="service-li-list">Maintains details of overhead and profits
                                                considered in the Project.
                                            </li>

                                            <li class="service-li-list">Provides estimate revisions and maintains
                                                history for of revision
                                                for comparison.</li>

                                            <li class="service-li-list">Integrates the tender cost and quantity
                                                during the project execution
                                                for effective tracking and monitoring ensuring there is no cost
                                                overrun and achieving targeted profit margins.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree"
                                        aria-expanded="false" aria-controls="collapseThree">
                                        Fixed Asset
                                    </h4>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintain asset master / register.</li>
                                                <li class="service-li-list">Supports multi-currency.</li>
                                                <li class="service-li-list">Provision to convert resources to fixed
                                                    assets.</li>
                                                <li class="service-li-list">Depreciation calculation as per Company and
                                                    IT act.</li>
                                                <li class="service-li-list">Provision to change the rate of
                                                    depreciation.</li>
                                                <li class="service-li-list">Integrates with Accounts department for
                                                    posting asset depreciation.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingFour">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour"
                                        aria-expanded="false" aria-controls="collapseFour">
                                        Procurement Management
                                    </h4>
                                </div>
                                <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Helps in procuring the right resource at
                                                    right time and at right price.</li>
                                                <li class="service-li-list">Supports multi-currency for import
                                                    purchases.</li>
                                                <li class="service-li-list">Seamless integration with Project, Stores
                                                    and Accounts departments.</li>
                                                <li class="service-li-list">Tracks project-wise purchases.</li>
                                                <li class="service-li-list">Maintains history of vendors and their rates
                                                    for analysis and procuring the resources from the right source.</li>
                                                <li class="service-li-list">Maintains taxes & duties details applicable
                                                    for the projects.</li>
                                                <li class="service-li-list">Accumulates purchase requests of multiple
                                                    projects for bulk purchasing.</li>
                                                <li class="service-li-list">Provides analysis of supplier quotations for
                                                    effective purchase.</li>
                                                <li class="service-li-list">Generates Purchase Orders based on project
                                                    requirements with detailed terms & conditions.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header" id="headingFive">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive"
                                        aria-expanded="false" aria-controls="collapseFive">
                                        Inventory Management
                                    </h4>
                                </div>
                                <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Seamless integration with Procurement and
                                                    Accounts department.</li>
                                                <li class="service-li-list">Provides accounting effects based on the
                                                    material movements.</li>
                                                <li class="service-li-list">Maintains multiple project warehouses.</li>
                                                <li class="service-li-list">Provides Activity based resource issues.
                                                </li>
                                                <li class="service-li-list">Provides project-wise stock register and
                                                    stock valuation reports.</li>
                                                <li class="service-li-list">Allows stock transfers from one-project to
                                                    another.</li>
                                                <li class="service-li-list">Maintains Production log of resources like
                                                    ready mix concrete.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header" id="headingSix">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix"
                                        aria-expanded="false" aria-controls="collapseSix">
                                        Mobility
                                    </h4>
                                </div>
                                <div id="collapseSix" class="collapse" aria-labelledby="headingSix"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Helps project team in reporting on field
                                                    activities such as Daily Progress Report (DPR), uploading project
                                                    progress photos, uploading MB, Material Requisition, etc.,</li>
                                                <li class="service-li-list">Helps stores team in uploading on site
                                                    transactions such as Purchase Requisition, MRN, GRN, Stock Transfer,
                                                    etc.,</li>
                                                <li class="service-li-list">Helps management team to approve the
                                                    Purchase Orders, Advance and Supplier Payment Certificates, etc., on
                                                    the move.</li>
                                                <li class="service-li-list">Helps sales team to post the on field
                                                    activities such as sales enquiries from the customers.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header" id="headingEight">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight"
                                        aria-expanded="false" aria-controls="collapseEight">
                                        Document Management
                                    </h4>
                                </div>
                                <div id="collapseEight" class="collapse" aria-labelledby="headingEight"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">CivitBUILD offers basic Document Management
                                                    features for both imported/uploaded documents and documents created
                                                    by the system across various modules and processes.</li>
                                                <li class="service-li-list">In the Bid Management module, the Tender
                                                    Document and Amendments are imported into the system.</li>
                                                <li class="service-li-list">Invoices provided by vendors can be uploaded
                                                    in the SubContractor Management Module or in the Accounts Module.
                                                </li>
                                                <li class="service-li-list">The system maintains work orders and payment
                                                    vouchers that are created within it.</li>
                                                <li class="service-li-list">Work Orders may come with amendments that
                                                    are included in different version numbers and/or new Work Order
                                                    numbers.</li>
                                                <li class="service-li-list">The system is capable of managing both
                                                    structured and unstructured documents that are incoming to the
                                                    system and also sent from the system.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Accordion -->
                </div>
            </div>

            <div class="row wow fadeInLeft" data-wow-delay=".30s">
                <div class="col-lg-6 thumb order-lg-2">
                    <h3 style="text-align:left;">CivitBUILD ERP Project Management</h3>
                    <div class="hr-line"></div>
                    <p style="padding-top:15px;">Efficiently oversee and coordinate tasks with our Project Management
                        solution, streamlining workflows, optimizing collaboration, and ensuring project success.</p>
                    <img src="<?php echo e(asset('assets/img/civitBUILD-project-management.png')); ?>" alt="Thumb" style=" height: 250px;">
                </div>
                <div class="col-lg-6 faq-items default-padding-bottom order-lg-1">
                    <!-- Start Accordion -->
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample2">
                            <div class="card">
                                <div class="card-header" id="heading1">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse1"
                                        aria-expanded="false" aria-controls="collapse1">
                                        Project Cost Management
                                    </h4>
                                </div>

                                <div id="collapse1" class="collapse" aria-labelledby="heading1"
                                    data-parent="#accordionExample2">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains the detailed Project Costing based
                                                    on the approved drawings and material specifications.</li>
                                                <li class="service-li-list">Integrates with Revit 3D model for
                                                    extracting the BOQ from the model file.</li>
                                                <li class="service-li-list">Maintains library of items with rate
                                                    analysis for quick generation of BOM.</li>
                                                <li class="service-li-list">Maintains Project Work Breakdown Structure
                                                    (WBS).</li>
                                                <li class="service-li-list">Supports multi-currency of the resources for
                                                    preparing the estimate.</li>
                                                <li class="service-li-list">Provides Direct and Indirect cost estimate
                                                    of the project during the bidding.</li>
                                                <li class="service-li-list">Plan, manage and track budget vs actual cost
                                                    for every project.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="heading2">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse2"
                                        aria-expanded="false" aria-controls="collapse2">
                                        Project Scheduling Management
                                    </h4>
                                </div>
                                <div id="collapse2" class="collapse" aria-labelledby="heading2"
                                    data-parent="#accordionExample2">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains project-wise activity calendar.
                                                </li>
                                                <li class="service-li-list">Maintains the Schedule Revisions.</li>
                                                <li class="service-li-list">Seamless integration with MS Project.</li>
                                                <li class="service-li-list">Integrates with Project Costing for tracking
                                                    the scope of work to be scheduled.</li>
                                                <li class="service-li-list">Maintains activity dependencies to auto
                                                    update the schedule.</li>
                                                <li class="service-li-list">Maintains the multiple baselines.</li>
                                                <li class="service-li-list">Provides Procurement Program for resources
                                                    for timely delivery.</li>
                                                <li class="service-li-list">Provides Cost Outflow based on scheduled
                                                    activity execution.</li>
                                                <li class="service-li-list">Tracks and Monitor Planned v/s Actual
                                                    Progress through Daily Progress update.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="heading3">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse3"
                                        aria-expanded="false" aria-controls="collapse3">
                                        Project Monitoring & Control
                                    </h4>
                                </div>
                                <div id="collapse3" class="collapse" aria-labelledby="heading3"
                                    data-parent="#accordionExample2">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Safeguard your projects from schedule and
                                                    cost overruns through 360 degree monitoring and unprecedented
                                                    control over your projects.</li>
                                                <li class="service-li-list">Tracks actual cost against budgeted cost of
                                                    the project.</li>
                                                <li class="service-li-list">Assigns project activities to the project
                                                    team and tracks its execution.</li>
                                                <li class="service-li-list">Records work measurements through daily
                                                    reports to update the project progress.</li>
                                                <li class="service-li-list">Generates activity based material
                                                    requisitions for project work execution.</li>
                                                <li class="service-li-list">Verifies and controls the resource
                                                    requisition quantity against the budgeted quantity.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="heading4">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse4"
                                        aria-expanded="false" aria-controls="collapse4">
                                        Sub Contractor Management
                                    </h4>
                                </div>
                                <div id="collapse4" class="collapse" aria-labelledby="heading4"
                                    data-parent="#accordionExample2">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Supports Item Rate, Lumpsum and Built-up
                                                    area type of work orders.</li>
                                                <li class="service-li-list">Integrates with Project BOQ to control the
                                                    scope of work to be outsourced.</li>
                                                <li class="service-li-list">Tracks service requests by the project team,
                                                    enquiries floated, vendor quotations.</li>
                                                <li class="service-li-list">Provides analysis of vendor quotation
                                                    along-with sensitivity analysis.</li>
                                                <li class="service-li-list">Maintains details of work orders & its
                                                    amendments, payment terms, terms & conditions, retentions and
                                                    advance recovery settings.</li>
                                                <li class="service-li-list">Tracks work done by the contractor through
                                                    measurements entries and consider the same for bill processing.</li>
                                                <li class="service-li-list">Manages retention recoveries and advance
                                                    adjustments while processing the contractor work done bills.</li>
                                                <li class="service-li-list">Tracks work done v/s payment released to the
                                                    contractors.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header" id="heading5">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse5"
                                        aria-expanded="false" aria-controls="collapse5">
                                        Client Sales Billing
                                    </h4>
                                </div>
                                <div id="collapse5" class="collapse" aria-labelledby="heading5"
                                    data-parent="#accordionExample2">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains and generate the Invoices against
                                                    the awarded tender as per the payment terms.</li>
                                                <li class="service-li-list">Seamless integration with Bid Management,
                                                    Project Execution and Accounts department to generate and posting of
                                                    the invoices.</li>
                                                <li class="service-li-list">Tracks Project Progress through Work Done
                                                    Measurements from Project Execution Department.</li>
                                                <li class="service-li-list">Generates Mobilization advance, Work done
                                                    and Material Advance Invoices.</li>
                                                <li class="service-li-list">Maintains Advance Adjustment and Retentions.
                                                </li>
                                                <li class="service-li-list">Provision to certify the bills from the
                                                    concerned authorities.</li>
                                                <li class="service-li-list">Identifies and tracks the variations and
                                                    price escalations.</li>
                                                <li class="service-li-list">Alerts based on the Agreed Payment Terms.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card">
                                <div class="card-header" id="heading6">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse6"
                                        aria-expanded="false" aria-controls="collapse6">
                                        Plant & Machinery Management
                                    </h4>
                                </div>
                                <div id="collapse6" class="collapse" aria-labelledby="heading6"
                                    data-parent="#accordionExample2">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains the Technical, Insurance and
                                                    Maintenance details of PnM.</li>
                                                <li class="service-li-list">Integrates with Projects department for
                                                    allocation of PnM.</li>
                                                <li class="service-li-list">Provision to generate the Project Machinery
                                                    Requirements.</li>
                                                <li class="service-li-list">Tracks Availability and Make Allotments to
                                                    the required Projects.</li>
                                                <li class="service-li-list">Dispatch and Transport the machineries to
                                                    the required Project Site.</li>
                                                <li class="service-li-list">Maintain Daily Logs of utilization of PnM.
                                                </li>
                                                <li class="service-li-list">Monitors efficiency and utilization of PnM.
                                                </li>
                                                <li class="service-li-list">Maintains repair and maintenance details of
                                                    PnM.</li>
                                                <li class="service-li-list">Cannibalization of PnM.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- End Accordion -->
                </div>

            </div>

            <div class="row wow fadeInRight" data-wow-delay=".50s">
                <div class="col-lg-6 thumb">
                    <h3 style="text-align:left;">HR & Payroll</h3>
                    <div class="hr-line"></div>
                    <p style="padding-top:15px;">Streamline personnel processes, payroll administration, and compliance
                        with a comprehensive solution.</p>
                        <!-- <p>Simplify workforce management, automate payroll tasks, and ensure
                        regulatory adherence for seamless human resources operations.</p> -->
                    <img src="<?php echo e(asset('assets/img/hr-payroll.png')); ?>" alt="Thumb" style="height: 250px;">
                </div>
                <div class="col-lg-6 faq-items default-padding-bottom">
                    <!-- Start Accordion -->
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample3">
                            <div class="card">
                                <div class="card-header" id="heading7">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse7"
                                        aria-expanded="false" aria-controls="collapse7">
                                        HR Features
                                    </h4>
                                </div>

                                <div id="collapse7" class="collapse" aria-labelledby="heading7"
                                    data-parent="#accordionExample3">
                                    <div class="card-body">

                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Fully detailed employee records with
                                                    complete history</li>
                                                <li class="service-li-list">Pre-onboarding file and data review</li>
                                                <li class="service-li-list">Manage Holidays, shifts, Loan / Advance,
                                                    Grades, Levels, Job types, Pension, Airfare.</li>
                                                <li class="service-li-list">Generates contract and legal documents.</li>
                                                <li class="service-li-list">Leave Accruals, Leave Balance, Leave
                                                    Encashment & Resumption, Leave Status & History</li>
                                                <li class="service-li-list">Manages concurrent contracts and multiple
                                                    occupations – part time, seasonal activity, entertainment.</li>
                                                <li class="service-li-list">Monitors and provides alerts for Insurance,
                                                    work permits, and regulatory authorisations documents expiry.</li>
                                                <li class="service-li-list">Your Employees, Managers and Users Have
                                                    Access to Real-Time Information from Multiple Locations
                                                    Simultaneously.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="heading8">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse8"
                                        aria-expanded="false" aria-controls="collapse8">
                                        Payroll Module
                                    </h4>
                                </div>
                                <div id="collapse8" class="collapse" aria-labelledby="heading8"
                                    data-parent="#accordionExample3">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains Employee profiles in a structured
                                                    and standard format.</li>
                                                <li class="service-li-list">Integrates with biometric devices for
                                                    importing attendance.</li>
                                                <li class="service-li-list">Maintains project wise employee attendance.
                                                </li>
                                                <li class="service-li-list">Generates of Project-wise salary register.
                                                </li>
                                                <li class="service-li-list">Facility to submit Leave, Loan & Advance
                                                    applications to the concerned authorities for approval.</li>
                                                <li class="service-li-list">Provision to handle all allowances &
                                                    deductions.</li>
                                                <li class="service-li-list">Integration with Accounts department for
                                                    salary processing.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="heading9">
                                    <h4 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse9"
                                        aria-expanded="false" aria-controls="collapse9">
                                        ESS Portal
                                    </h4>
                                </div>
                                <div id="collapse9" class="collapse" aria-labelledby="heading9"
                                    data-parent="#accordionExample3">
                                    <div class="card-body">

                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Apply for leave, Loan, Advances</li>
                                                <li class="service-li-list">Workflow Approvals</li>
                                                <li class="service-li-list">Manage their Leaves, attendance, and
                                                    Holidays
                                                </li>
                                                <li class="service-li-list">Leave Management status Updates
                                                </li>
                                                <li class="service-li-list">Manage their own personal details like bank
                                                    accounts and next-of-kin information.</li>
                                                <li class="service-li-list">View current and previous payslips and print
                                                    selected reports.</li>
                                                <li class="service-li-list">Personal & Team Information</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Accordion -->
                </div>
            </div>
        </div>
    </div>


    <section aria-label="section" class="mobile-section" style="background: url(<?php echo e(asset('assets/img/shape/j.avif')); ?>);
    background-attachment: fixed;background-position: top;background-repeat: no-repeat;background-size: cover;"
        id="Who-use-CivitBUILD">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 offset-lg-2 text-center">
                    <div class="site-heading text-center" style="margin-bottom: 20px;">
                        <h2>Who Can Use <span>CivitBUILD Contracting ERP</span> Software ? </h2>
                    </div>
                </div>
            </div>

            <div class="row align-items-center">
                <div class="col-lg-4">
                    <div class="box-icon box-shadow s2 p-small mb20 wow fadeInRight" data-wow-delay=".5s"
                        style="margin-top: 25px; background:#ffff;">
                        <div class="icon text-center">
                            <img src="<?php echo e(asset('assets/img/icon/enterprise.png')); ?>" width="70px" alt="" />
                        </div>
                        <div class="d-inner text-center">
                            <h4 class="text-blue">Companies In The Contracting Industry Seeking To Expand And Enhance
                                Their Business</h4>
                        </div>
                    </div>
                    <div class="box-icon box-shadow s2 p-small mb20 wow fadeInL fadeInRight" data-wow-delay=".75s"
                        style="margin-top: 25px; background:#ffff;">
                        <div class="icon text-center">
                            <img src="<?php echo e(asset('assets/img/icon/content.png')); ?>" width="70px" alt="" />
                        </div>
                        <div class="d-inner text-center">
                            <h4 class="text-blue">Contracting Companies Use Multiple Software In Their Department</h4>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <img src="<?php echo e(asset('assets/img/mobile-dashboard-2.png')); ?>" alt="" height="400px" width="85%"
                        class="img-fluid wow fadeInUp mobile-img-p hide-in-mobile">
                </div>

                <div class="col-lg-4">
                    <div class="box-icon box-shadow s2 d-invert p-small mb20 wow fadeInL fadeInLeft" data-wow-delay="1s"
                        style="margin-top: 25px; background:#ffff;">
                        <div class="icon text-center">
                            <img src="<?php echo e(asset('assets/img/icon/revenue.png')); ?>" width="70px" alt="" />
                        </div>
                        <div class="d-inner text-center">
                            <h4 class="text-blue">Established Contracting Companies</h4>

                        </div>
                    </div>
                    <div class="box-icon box-shadow s2 d-invert p-small mb20 wow fadeInL fadeInLeft"
                        data-wow-delay="1.25s" style="margin-top: 25px; background:#ffff;">
                        <div class="icon text-center">
                            <img src="<?php echo e(asset('assets/img/icon/needs.png')); ?>" width="70px" alt="" />
                        </div>
                        <div class="d-inner text-center">
                            <h4 class="text-blue">Contracting Companies Expanding To New Fields & Activities</h4>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Start Features 
    ============================================= -->
    <div id="Why-CivitBUILD" class="bg-gray features-area default-padding bottom-small" style="background: url(<?php echo e(asset('assets/img/shape/17.png')); ?>);
    background-attachment: fixed;background-position: top;background-repeat: no-repeat;background-size: cover;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2>Why CivitBUILD <span>Construction and Contracting</span> ERP Software?</h2>
                        <p>
                            Enhance your productivity, streamline communication, and accelerate your project
                            development, all from a centralized, reliable source. Explore the extensive capabilities of
                            the premium construction management platform and discover how you can achieve more in less
                            time.
                        </p>
                    </div>
                </div>
            </div>
            <div class="features-items">
                <div class="row">
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <!-- <i class="flaticon-scroll"></i> -->
                                <img src="<?php echo e(asset('assets/img/icon/big-data-analytics.png')); ?>" class="img-res"
                                    alt="Process Driven" />
                            </div>
                            <div class="info">

                                <h4>Process Driven</h4>

                                <p>
                                    Transforming construction with advanced ERP and project management solutions.
                                    Streamlining industry-standard processes for heightened efficiency and success in
                                    every project
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/custom.png')); ?>" class="img-res"
                                    alt="Flexible & Customizable" />
                            </div>
                            <div class="info">
                                <h4>Flexible & Customizable</h4>
                                <p>
                                    CivitBuild offers customizable Construction ERP and Project Management software,
                                    tailored to your business needs. Streamline operations, enhance collaboration.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/decision-making.png')); ?>" class="img-res"
                                    alt="Decision Making Tool" />
                            </div>
                            <div class="info">
                                <h4>Decision Making Tool ​</h4>
                                <p>
                                    Smart decision-making with our construction ERP and project management software.
                                    Gain real-time insights through powerful business intelligence and intuitive
                                    dashboards.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/resize.png')); ?>" class="img-res" alt="Scalable" />
                            </div>
                            <div class="info">
                                <h4>Scalable</h4>
                                <p>
                                    CivitBUILD contracting & construction ERP crafted to meet the growing demands of
                                    your expanding enterprise. Stay agile, streamline processes, and thrive in a dynamic
                                    construction market with CivitBuild
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/easy-access.png')); ?>" class="img-res"
                                    alt="Access Anywhere Anytime" />
                            </div>
                            <div class="info">
                                <h4>Access Anywhere Anytime​ </h4>
                                <p>
                                    Revolutionizing construction management with cloud-powered ERP and project
                                    solutions. Experience unparalleled mobility from anywhere, empowering seamless
                                    collaboration and project control.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/futuristic.png')); ?>" class="img-res"
                                    alt="Futuristic" />
                            </div>
                            <div class="info">
                                <h4>Futuristic </h4>
                                <p>
                                    CivitBUILD project management software for the future. Stay ahead with innovative
                                    solutions tailored to embrace rapid technological change in the construction
                                    industry.
                                </p>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Features -->

    <!-- Start Overview 
    ============================================= -->
    <div id="overview" class="overview-area default-padding" style="background-image: url(<?php echo e(asset('assets/img/shape/51.png' )); ?>); background-position: top;
    background-repeat: no-repeat;
    background-size: cover;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2>Quick <span>Software</span> Overview</h2>
                        <p>
                            Experience streamlined business management with our ERP Software. Gain real-time insights,
                            automate workflows, and achieve unparalleled efficiency. Tailored for your success, it's the
                            future of ERP solutions.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 text-center overview-items">
                    <div class="overview-carousel owl-carousel owl-theme">
                        <img src="<?php echo e(asset('assets/img/app/Sales-CRM-Dashboard.avif')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Dashboard.avif')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Inventory-Dashboard.avif')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Financial-Accounting.avif')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Payroll.avif')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Client-BOQ.avif')); ?>" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Overview -->


    <div id="strip" class="strip-section"
        style="background-image: url(<?php echo e(asset('assets/img/shape/bg-2.jpg' )); ?>); text-align:center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-heading text-center" style="margin-bottom:30px;">
                        <h2 class="text-white"><span
                                style="color:#0070bc;  -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: white; ">Customizable
                                ERP</span> for Construction Business</h2>
                        <p class="text-white">Integrated, customizable Construction ERP streamlining project management
                            for enhanced efficiency and collaboration with CivitBuild.</p>
                    </div>
                </div>
            </div>
            <div class="row align-center justify-content-center">
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon1.png')); ?>" alt="" width="100px" height="100px" />
                        <p class="text-white strip-desc">Modular based for an easy pick-and-choose as per your unique
                            needs</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon2.png')); ?>" alt="" width="80px" height="80px" />
                        <p class="text-white strip-desc">Integrate with 3rd Party Accounting Software</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon3.png')); ?>" alt="" width="80px" height="80px" />
                        <p class="text-white strip-desc">Integrate with Microsoft Project & Primavera</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon4.png')); ?>" alt="" width="80px" height="80px" />
                        <p class="text-white strip-desc">Integrates with Microsoft Dynamics </p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon6.png')); ?>" alt="" width="80px" height="80px" />
                        <p class="text-white strip-desc">Integrates fully with Rivet BIM to generate BOQ</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <section class="video-section bg-gray text-center">

        <div class="container">
            <div class="row" style="background:#ffff;">
                <div class="col-lg-5">
                    <!-- <div class="left-border gradient"> -->
                    <div class="banner">
                        <img src="<?php echo e(asset('assets/img/video-thum2-flip-left.png')); ?>" class="video-thum1" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/video-thum-mobile.jpg')); ?>" class="video-thum2" alt="Thumb">
                        <div class="overlay">
                            <a class="popup-youtube video-play-button"
                                href="<?php echo e(asset('assets/video/CivitBUILD-Advantage.mp4')); ?>">
                                <i class="fa fa-play"></i>
                            </a>
                        </div>

                        <!-- <video width="350" height="290" controls>
                                            <source src="<?php echo e(asset('assets/video/CivitBUILD-Advantage.mp4')); ?>"
                                                type="video/mp4">
                                        </video> -->

                        <!-- <iframe class="embed-responsive embed-responsive-16by9" width="560" height="315"
                    src="https://www.youtube.com/embed/_1rZUpLBgjA" title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe> -->

                        <!-- </div> -->
                    </div>
                </div>
                <div class="col-lg-7 ">
                    <div class="content content-pd" data-animation="animated fadeInUpBig">
                        <h2 style="font-size:45px; text-align:left;">CivitBUILD <span style="color:#0070bc;">Advantage</span></h2>
                        <p style="text-align:left; padding: 0;">CivitBuild is a construction management
                            leader that provides a strong platform enhanced with customizable workflows,
                            role-based access controls, and thorough organization oversight. CivitBuild
                            prioritizes empowering efficiency and collaboration by ensuring seamless
                            construction processes, from customized workflows to thorough organization
                            management, thereby laying the groundwork for unmatched project success.</p>
                        <p style="text-align:left; padding: 0;">By emphasizing customization in workflows
                            and meticulous organizational oversight, CivitBuild establishes a strong
                            foundation for achieving unparalleled success in construction projects.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <!-- Start Testimonials 
    ============================================= -->
    <div class="testimonials-area default-padding" id="reviews"
        style="background: url(<?php echo e(asset('assets/img/shape/jk.avif')); ?>); background-position: top;background-repeat: no-repeat;background-size: cover;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading single text-center">
                        <!--<h2>Customer Review</h2>-->
                        <h2>Our Customer Words <span>About CivitBUILD</span></h2>
                        <p>What outcomes did our clients attain through the implementation of CivitBUILD contracting
                            and
                            construction ERP?</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="demo1">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <span class="top-icon" style="color:#00ba50"><i class="fa fa-quote-left"></i></span>
                                    <div id="testimonial-slider" class="owl-carousel">
                                        <div class="testimonial">
                                            <div class="testimonial-content">
                                                <h3 class="testimonial-title color-white">Anil Bakeri - Chairman &
                                                    Managing Director</h3>
                                                <p class="description color-white">
                                                    Soft Tech people know the construction business well. The
                                                    product
                                                    helped in interconnection our various project sites,
                                                    departments,
                                                    and office - which made MIS consolidation across organization
                                                    quicker. Being a value-for-money proposition, we were able to
                                                    generate a clear ROI on CivitBUILD implementation
                                                </p>
                                            </div>
                                        </div>

                                        <div class="testimonial">
                                            <div class="testimonial-content">
                                                <h3 class="testimonial-title color-white">Dr. Samar Daham Hatoum -
                                                    General manager </h3>
                                                <p class="description color-white">
                                                    CivitBUILD has enhanced the efficiency and effectiveness of our
                                                    Sop's through the integration and automation offered by the
                                                    software. It's a well designed system that addresses the
                                                    management
                                                    cycle of construction projects skillfully. The SoftTech team did
                                                    a
                                                    super job throughout the training and implementation processes.
                                                    Soft
                                                    Tech indeed has a unique approach to attending to their
                                                    customers
                                                    business needs, which is a key to the success of any service
                                                    business.
                                                </p>
                                            </div>
                                        </div>

                                        <div class="testimonial">
                                            <div class="testimonial-content">
                                                <h3 class="testimonial-title color-white">Mr. Anand Joshi - Director
                                                    (Civil)</h3>
                                                <p class="description color-white">
                                                    It has been a great journey till now to be a part of the
                                                    CivitBUILD
                                                    Family. CivitBUILD has provided the solution of our pain points
                                                    which we were suffering from last few years and due to the
                                                    number of
                                                    Projects were increasing it was not easy for us to manage
                                                    everything
                                                    from a common platform. CivitBUILD, we have much better control
                                                    over
                                                    our policies and procedures, our expenditures, and our
                                                    forecasts. In
                                                    addition, the CivitBUILD support team has done a wonderful job
                                                    in
                                                    guiding us through the implementation process and continues to
                                                    provide us with outstanding support after the fact; also the
                                                    response to tackling any reported issue is remarkable, this, in
                                                    turn, concludes that CivitBUILD adopts the unique approach
                                                    strategy
                                                    to meet customers’ business needs, which in my opinion, is a key
                                                    to
                                                    the success of any service business. So SoftTech is definitely
                                                    here
                                                    to stay!
                                                </p>
                                            </div>
                                        </div>

                                        <div class="testimonial">
                                            <div class="testimonial-content">
                                                <h3 class="testimonial-title color-white">Mr. Parag Dnyandeo Patil -
                                                    Director (Civil)</h3>
                                                <p class="description color-white">
                                                    Being a member of the CIVITBUILD family has been a fantastic
                                                    experience thus far. CIVITBUILD has provided a solution to the
                                                    pain
                                                    points that we had been experiencing over the past few years,
                                                    and it
                                                    was becoming increasingly difficult for us to manage everything
                                                    from
                                                    a single platform as the number of projects grew. We have
                                                    considerably better control over our policies and procedures,
                                                    expenditures, and forecasts thanks to CivitBUILD. Furthermore,
                                                    the
                                                    CivitBUILD Implementation team & support team has done an
                                                    outstanding job guiding us through the implementation process
                                                    and
                                                    continues to provide us with outstanding support after the fact;
                                                    also, the response time to any reported issue is remarkable,
                                                    which
                                                    concludes that CivitBUILD uses a unique approach strategy to
                                                    meet
                                                    customers' business needs, which, in my opinion, is a key to any
                                                    service business's success. SoftTech is unquestionably here to
                                                    stay!"
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <span style="padding-bottom:15px;"></span> -->
                                    <span class="bottom-icon" style="color:#00ba50"><i
                                            class="fa fa-quote-right"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials -->


    <div class="col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-lg">
        <div class="container">
            <div class="col-lg-6 col-sm-6 col-xs-6 div-line pd0">
                <a href="tel:+971 50 383 4122" class="fix-link callme">
                    <i class="fa fa-phone f-icon" aria-hidden="true"></i> CALL NOW
                </a>
            </div>

            <div class="col-lg-6 col-sm-6 col-xs-6 pd0">
                <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal"><button
                        class="btn1 fix-link i-am"><i class="fa fa-envelope"></i> ENQUIRE NOW</button></a>

                <!-- <button class="btn1 fix-link i-am"><i class="fa fa-envelope"></i> ENQUIRE NOW</button> -->
            </div>
        </div>
    </div>


    <div id="overview" class="overview-area default-padding"
        style="background-image: url(<?php echo e(asset('assets/img/civit-bg-img.jpg' )); ?>); text-align:center">
        <div class="container border-color card">
            <div class="double-items thumb-140">
                <div class="row align-center"
                    style=" background: url(http://localhost:8000/assets/img/shape/17.png); background-attachment: fixed; background-position: top; background-repeat: no-repeat;  background-size: cover;">
                    <div class="col-lg-8 left-info simple-video">
                        <div class="content" data-animation="animated fadeInUpBig">
                            <h5 style="font-weight: 600; color:#000; font-size:28px; text-align: center;">Ready to
                                experience what <span style="color:#00ba50">CivitBUILD</span> can do for your
                                construction
                                business? Specially <span style="color:#00ba50">designed for UAE</span>
                            </h5>
                            <a class="btn circle btn-theme-n border-n btn-md" href="javascript:void(0)"
                                data-toggle="modal" data-target="#myModal">Request a Demo</a>
                        </div>
                    </div>
                    <div class="col-lg-4 right-info">
                        <img src="<?php echo e(asset('assets/img/fotoer-clip-art.png')); ?>" height="200px" />
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!-- Start Footer 
    ============================================= -->
    <footer class="bg-light">
        <div class="container">
            <!-- Start Footer Bottom -->
            <div class="footer-bottom">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <p>&copy; Copyright <script type="text/javascript">
                                document.write(new Date().getFullYear());
                                </script>. All Rights Reserved.</a></p>
                        </div>
                        <div class="col-lg-6 text-right link">
                            <ul>
                                <li>
                                    <a href="tel: +97 15 0383 4122">+97 15 0383 4122</a>
                                </li>
                                <li>
                                    <a href="mailto: measales@thecivit.com">measales@thecivit.com</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer Bottom -->
        </div>
    </footer>
    <!-- End Footer -->

    <!-- Enquiry modal -->
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h3 class="modal-title" style="font-size:25px;">Enquire Now!</h3>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="contact-form">
                        <form action="<?php echo e(route('enquires')); ?>" method="POST" class="contact-form"
                            id="home-enquire-form">
                            <?php echo csrf_field(); ?>


                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                            </div>
                            <?php endif; ?>

                            <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="fName" name="fName" placeholder="First Name"
                                            type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="lName" name="lName" placeholder="Last Name"
                                            type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="email2" name="email"
                                            placeholder="Corporate Email ID" type="text" required>
                                        <span class="error-message" id="emailError2"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" type="tel" id="phone2" name="phone"
                                            placeholder="Phone Number">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="designation" name="designation"
                                            placeholder="Designation" type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <select class="form-control" id="companyType" name="companyType"
                                            style="height: 50px;" required>
                                            <option disabled="" selected="" value="">Select Company Type
                                            </option>
                                            <option value="General Contractor">General Contractor</option>
                                            <option value="Specialty Contractor">Specialty Contractor
                                            </option>
                                            <option value="Owner or Developer">Owner or Developer</option>
                                            <option value="Government">Government</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="companyName" name="companyName"
                                            placeholder="Company Name" type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="companyWebsite2" name="companyWebsite"
                                            placeholder="Company Website" type="text" required>
                                        <span class="error-message" id="websiteError2"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <span id="country-code2" style="display: none;"></span>
                                        <input class="form-control" id="country-name2" name="country"
                                            value="United Arab Emirates" placeholder="Country" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="city" name="city" placeholder="City"
                                            type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group comments">
                                        <textarea class="form-control" id="aboutProject" name="aboutProject"
                                            placeholder="Tell Us About Project"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12" style="text-align:center;">
                                    <button type="submit" name="submit" id="submit" class="contact-form-button">
                                        Get a Free Demo Now
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Modal footer -->
                <!-- <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div> -->

            </div>
        </div>
    </div>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modernizr.custom.13711.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/count-to.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootsnav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/intlTelInput.js')); ?>"></script>

    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script> -->

    <script>
        var emailInput1 = document.getElementById('email1');
        var emailError1 = document.getElementById('emailError1');
        var websiteInput1 = document.getElementById('companyWebsite1');
        var websiteError1 = document.getElementById('websiteError1');

        var emailInput2 = document.getElementById('email2');
        var emailError2 = document.getElementById('emailError2');
        var websiteInput2 = document.getElementById('companyWebsite2');
        var websiteError2 = document.getElementById('websiteError2');

        emailInput1.addEventListener('input', function () {
            validateEmail(emailInput1, emailError1);
        });

        websiteInput1.addEventListener('input', function () {
            validateWebsite(websiteInput1, websiteError1);
        });

        emailInput2.addEventListener('input', function () {
            validateEmail(emailInput2, emailError2);
        });

        websiteInput2.addEventListener('input', function () {
            validateWebsite(websiteInput2, websiteError2);
        });

        function validateForm1() {
            validateEmail(emailInput1, emailError1);
            validateWebsite(websiteInput1, websiteError1);
            // Add additional validation logic if needed for Form 1
        }

        function validateForm2() {
            validateEmail(emailInput2, emailError2);
            validateWebsite(websiteInput2, websiteError2);
            // Add additional validation logic if needed for Form 2
        }

        function validateEmail(emailInput, emailError) {
            // Regular expression for an email ID excluding gmail.com and yahoo.com
            var emailRegex =
                /^[a-zA-Z0-9._%+-]+@(?!gmail\.com|yahoo\.com|outlook\.com|zoho\.com|protonmail\.com|mail\.com|gmx\.com|yandex\.com|aol\.com|tutanota\.com)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

            if (emailRegex.test(emailInput.value)) {
                // Valid email
                emailError.textContent = '';
            } else {
                // Invalid email
                emailError.textContent = 'Please enter a valid professional email address.';
            }
        }

        function validateWebsite(websiteInput, websiteError) {
            // Regular expression for a basic website URL
            var websiteRegex = /^(http(s)?:\/\/)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\S*)?$/;

            if (websiteRegex.test(websiteInput.value)) {
                // Valid website
                websiteError.textContent = '';
            } else {
                // Invalid website
                websiteError.textContent = 'Please enter a valid website URL';
            }
        }
    </script>

<script>
        // Form 1
        var input1 = document.querySelector('#phone1');
        var countryCodeSpan1 = document.querySelector('#country-code1');
        var countryNameInput1 = document.querySelector('#country-name1');
        var iti1 = window.intlTelInput(input1, {});

        updatePhoneNumber1(); // Set initial phone number

        input1.addEventListener('input', function() {
            // Check if the entered number starts with the selected country code
            if (!input1.value.startsWith('+' + iti1.getSelectedCountryData().dialCode)) {
                updatePhoneNumber1();
            }
        });

        input1.addEventListener('countrychange', function() {
            updateCountryCode1();
            updateCountryName1();
        });

        function updateCountryCode1() {
            var selectedCountryData = iti1.getSelectedCountryData();
            countryCodeSpan1.textContent = '+' + selectedCountryData.dialCode;
        }

        function updateCountryName1() {
            var selectedCountryData = iti1.getSelectedCountryData();
            countryNameInput1.value = selectedCountryData.name;
        }

        function updatePhoneNumber1() {
            var phoneNumber = input1.value.replace(/\D/g, ''); // Remove non-numeric characters
            var selectedCountryData = iti1.getSelectedCountryData();
            input1.value = '+' + selectedCountryData.dialCode + phoneNumber;
        }

        // Form 2
        var input2 = document.querySelector('#phone2');
        var countryCodeSpan2 = document.querySelector('#country-code2');
        var countryNameInput2 = document.querySelector('#country-name2');
        var iti2 = window.intlTelInput(input2, {});

        updatePhoneNumber2(); // Set initial phone number

        input2.addEventListener('input', function() {
            // Check if the entered number starts with the selected country code
            if (!input2.value.startsWith('+' + iti2.getSelectedCountryData().dialCode)) {
                updatePhoneNumber2();
            }
        });

        input2.addEventListener('countrychange', function() {
            updateCountryCode2();
            updateCountryName2();
        });

        function updateCountryCode2() {
            var selectedCountryData = iti2.getSelectedCountryData();
            countryCodeSpan2.textContent = '+' + selectedCountryData.dialCode;
        }

        function updateCountryName2() {
            var selectedCountryData = iti2.getSelectedCountryData();
            countryNameInput2.value = selectedCountryData.name;
        }

        function updatePhoneNumber2() {
            var phoneNumber = input2.value.replace(/\D/g, ''); // Remove non-numeric characters
            var selectedCountryData = iti2.getSelectedCountryData();
            input2.value = '+' + selectedCountryData.dialCode + phoneNumber;
        }
    </script>


    <script>
    $(document).ready(function() {
        $("#testimonial-slider").owlCarousel({
            items: 1,
            itemsDesktop: [1000, 1],
            itemsDesktopSmall: [979, 1],
            itemsTablet: [768, 1],
            pagination: true,
            slideSpeed: 1000,
            singleItem: true,
            animateOut: 'animate__fadeOut animate__animated animate__slideOutLeft', // Combination for fadeOut and slideOutUp
            animateIn: 'animate__fadeIn animate__animated animate__slideInRight', // Combination for fadeIn and slideInUp
            autoplay: true,
            loop: true
        });
    });
    </script>


    <!-- <script>
    $(document).ready(function() {
        $('.form-control').on('input', function() {
            var phoneInput = $(this).val();
            var phoneError = $(this).siblings('.phone-error');
            var phonePattern = /^\d{10}$/;

            if (!phonePattern.test(phoneInput)) {
                phoneError.text('Please enter a valid phone number.');
            } else {
                phoneError.text('');
            }
        });
    });
    </script> -->

</body>

</html><?php /**PATH C:\xampp\htdocs\CivitBUILD\new-backup\resources\views/home-page/index.blade.php ENDPATH**/ ?>
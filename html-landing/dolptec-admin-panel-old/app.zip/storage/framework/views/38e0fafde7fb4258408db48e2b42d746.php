<!DOCTYPE html>

<html>

<head>
    <title>Customer Mail </title>
</head>

<body>

    <p> Dear <?php echo e($fromName); ?>,</p>

    <p>Thank you for expressing interest in civitBUILD. We appreciate the time you took to fill out our enquiry form.</p>

    <p>Our team is excited to explore how civitBUILD can address your specific project management needs, whether you're an owner, builder, or contractor. Expect a call from one of our dedicated representatives soon, ready to discuss your requirements and showcase the features that set civitBUILD apart.</p>

    <p>We look forward to the opportunity to assist you in optimizing your construction projects. If you have any immediate questions, feel free to contact us.</p>

    
    Warm Regards,<br>
    CivitBUILD<br>
    Phone: +97 15 0383 4122<br>
    measales@thecivit.com
    
    

</body>
</html><?php /**PATH C:\xampp\htdocs\CivitBUILD\civitbuild.credtify.com\resources\views/email-body/email-enquiry2.blade.php ENDPATH**/ ?>
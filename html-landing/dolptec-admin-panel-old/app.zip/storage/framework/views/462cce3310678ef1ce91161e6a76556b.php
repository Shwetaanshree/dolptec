<!DOCTYPE html>

<html>

<head>
    <title>Customer Mail </title>
</head>

<body>

    <p> Dear <?php echo e($fromName); ?>,</p>

   <p>We appreciate your interest in CivitBUILD, our specialized Construction ERP Software.</p>

<p><strong>Our Client Success Manager will be reaching out to you very soon.</strong></p>

<p><strong>Meanwhile, know more about our specialized CivitBUILD solutions:</strong></p>

<p><a href="https://thecivit.com/software-for-builders-developers/">Construction Operations for Builders & Developers</a><br>

<a href="https://thecivit.com/construction-management-software-for-contractors/">Bidding and Project Management for Contractors</a></p>

    
   <p>Best Regards,<br>
<strong>Dijo Jose</strong><br>
Regional Director – MEA</p>

<p><strong><span style="color:#0b93ef;font-size:15px;">SoftTech Digital Software LLC, Dubai, UAE</span></strong><br>
<strong><strong>E:</strong> <a href="mailto:dijo.jose@softtech-engr.com">dijo.jose@softtech-engr.com </a> | W:</strong> <a href="https://thecivit.com/">www.thecivit.com</a> | <strong>M:</strong> <a href="tel:+971503834122">+971 50 383 4122</a> |<br>
<strong>Corporate website</strong> : <a href="https://softtech-engr.com/">www.softtech-engr.com</a> | <a href="https://calendly.com/dijo-jose">Book a Meeting</a> <br>
<span style="color:	#A9A9A9;"><strong>US | UK | MEA | Asia Pacific | India</strong></span></p>
    
    

</body>
</html><?php /**PATH /home4/saletc4y/civitbuild.credtify.com/resources/views/email-body/email-enquiry2.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">


<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="Purpose-built Integrated Construction Project Management Software For Builders, Contractors and Owners | CivitBuild - Construction ERP Software">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- ========== Page Title ========== -->
    <title>Construction Project Management Software For Owners, Builders and Contractors</title>

    <base href="<?php echo e(asset('public')); ?>/">

    <!-- ========== Favicon Icon ========== -->
    <!-- <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon"> -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/favicon_io/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/favicon_io/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/favicon_io/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/favicon_io/site.webmanifest')); ?>">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/elegant-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/flaticon-set.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/bootsnav.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" />

    <!-- <link href="<?php echo e(asset('assets/css/demo.css')); ?>" rel="stylesheet" /> -->
    <link href="<?php echo e(asset('assets/css/intlTelInput.css')); ?>" rel="stylesheet" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />


    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.css"> -->

    <!-- ========== End Stylesheet ========== -->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">

    <script type="text/javascript">
    function callbackThen(response) {
        // read Promise object
        response.json().then(function(data) {
            console.log(data);
            if (data.success && data.score > 0.5) {
                console.log('valid recpatcha');
            } else {              

                document.getElementById('modal-enquire-form').addEventListener('submit', function(event) {
                    event.preventDefault();
                    alert('recpatcha error');
                });
            }
        });
    }

    function callbackCatch(error) {
        console.error('Error:', error)
    }
    </script>

    <?php echo htmlScriptTagJsApi([
    'callback_then' => 'callbackThen',
    'callback_catch' => 'callbackCatch',
    ]); ?>


    <style>
    .demo {
        /* background: linear-gradient(to right ,#f33963 ,#ff735b); */
        /* background: linear-gradient(to right ,#0070bc ,#0070bc); */
        background: linear-gradient(to right, #0070bc3b, #0070bc9c);
    }

    .top-icon,
    .bottom-icon {
        display: block;
        font-size: 70px;
        color: #fdfeff;
        text-align: center;
        margin: 0 auto;
    }

    .testimonial {
        padding: 0 40px;
        position: relative;
        overflow: hidden;
        /* background: linear-gradient(to right ,#ff735b ,#f33963); */
        background: linear-gradient(to right, #0070bc, #00ba50);
        color: #fdfeff;
        z-index: 1;
    }

    .testimonial:after {
        content: "";
        width: 150px;
        height: 107%;
        background: #00ba5099;
        position: absolute;
        top: -20px;
        left: -60px;
        transform: matrix(1, 0, 0.5, 1, 150, 0);
        z-index: -1;
    }

    .testimonial .pic {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        overflow: hidden;
        float: left;
        margin: 10px 25px 0 0;
        position: relative;
    }

    .testimonial .pic img {
        width: 100%;
        height: auto;
    }

    .testimonial .testimonial-content {
        width: 100%;
        height: 250px;
        float: right;
        padding: 30px 0;
    }

    .testimonial .testimonial-title {
        font-size: 20px;
        font-weight: 900;
        margin: 0 0 20px;
        text-transform: capitalize;
    }

    .testimonial .description {
        font-size: 14px;
        line-height: 26px;
    }

    .owl-theme .owl-controls .owl-page span {
        width: 10px;
        height: 10px;
        background: #fff;
        border: 2px solid #1ec4f3;
    }

    .owl-theme .owl-controls .owl-page:active span {
        color: #1ec4f3;
    }

    @media only screen and (max-width: 767px) {
        .testimonial {
            text-align: center;
        }

        .testimonial .pic {
            float: none;
            margin: 20px auto 0;
        }

        .testimonial .testimonial-content {
            width: 100%;
            height: 800px;
            float: none;
            padding: 20px 0;
        }

        .testimonial .description {
            font-size: 14px;
        }
    }

    @media only screen and (max-width: 480px) {
        .testimonial {
            padding: 0 20px;
        }

        .testimonial .testimonial-title {
            font-size: 22px;
        }
    }

    .error-message {
        color: red;
    }
    </style>
</head>


<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Header 
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-fixed dark no-background bootsnav">

            <div class="container-fill">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav button">
                    <ul>
                        <li>
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal">Enquire
                                Now</a>
                            <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                                Open modal
                            </button> -->
                        </li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->



                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars" style="color:#ffff;"></i>
                    </button>
                    <a class="navbar-brand" href="/">
                        <img src="<?php echo e(asset('assets/img/logo2.png')); ?>" class="logo logo-display" alt="Logo">
                        <img src="<?php echo e(asset('assets/img/logo2.png')); ?>" class="logo logo-scrolled" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="#" data-out="#">
                        <li class="dropdown dropdown-right">
                            <a href="/" class="smooth-menu">Home</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#Features">Features</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#Who-use-CivitBUILD">Who use CivitBUILD</a>
                        </li>
                        
                        <li>
                            <a class="smooth-menu" href="#Why-CivitBUILD">Why CivitBUILD</a>
                        </li>

                        <li>
                            <a class="smooth-menu" href="#reviews">Reviews</a>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->

    <!-- Start 404 
    ============================================= -->
    <div class="thank-page-area bg-gray text-center" style="padding:150px 0 100px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Thank You</h1>
                    <h3>You have successfully submitted your enquiry. We will get back to you as soon as possible.</h3>
                    <p>
                    You will receive a confirmation email please check!
                    </p>
                    <a class="btn btn-theme effect btn-md" href="/">Back To Home</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End 404 -->

   
    <!-- Start Footer 
    ============================================= -->
    <footer class="bg-light">
        <div class="container">
            <!-- Start Footer Bottom -->
            <div class="footer-bottom">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <p>&copy; Copyright <script type="text/javascript">
                                document.write(new Date().getFullYear());
                                </script>. All Rights Reserved.</a></p>
                        </div>
                        <div class="col-lg-6 text-right link">
                            <ul>
                                <li>
                                    <a href="tel: +97 15 0383 4122">+97 15 0383 4122</a>
                                </li>
                                <li>
                                    <a href="mailto: measales@thecivit.com">measales@thecivit.com</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer Bottom -->
        </div>
    </footer>
    <!-- End Footer -->

    <!-- Enquiry modal -->
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h3 class="modal-title">Enquire Now!</h3>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="contact-form">
                    <form action="<?php echo e(route('enquires')); ?>" method="POST" class="contact-form"
                            id="home-enquire-form">
                            <?php echo csrf_field(); ?>


                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(Session::get('error')); ?>

                            </div>
                            <?php endif; ?>

                            <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="fName" name="fName" placeholder="First Name"
                                            type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="lName" name="lName" placeholder="Last Name"
                                            type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="email" name="email"
                                            placeholder="Corporate Email ID" type="text" required>
                                        <span class="error-message" id="emailError"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" type="tel" id="phone" name="phone"
                                            placeholder="Phone Number">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="designation" name="designation"
                                            placeholder="Designation" type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <select class="form-control" id="companyType" name="companyType"
                                            style="height: 50px;" required>
                                            <option disabled="" selected="" value="">Select Company Type
                                            </option>
                                            <option value="General Contractor">General Contractor</option>
                                            <option value="Specialty Contractor">Specialty Contractor
                                            </option>
                                            <option value="Owner or Developer">Owner or Developer</option>
                                            <option value="Government">Government</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="companyName" name="companyName"
                                            placeholder="Company Name" type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="companyWebsite" name="companyWebsite"
                                            placeholder="Company Website" type="text" required>
                                        <span class="error-message" id="websiteError"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <span id="country-code" style="display: none;"></span>
                                        <input class="form-control" id="country-name" name="country"
                                            value="United Arab Emirates" placeholder="Country" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="city" name="city" placeholder="City"
                                            type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group comments">
                                        <textarea class="form-control" id="aboutProject" name="aboutProject"
                                            placeholder="Tell Us About Project"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12" style="text-align:center;">
                                    <button type="submit" name="submit" id="submit" class="contact-form-button">
                                        Get a Free Demo Now
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Modal footer -->
                <!-- <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div> -->

            </div>
        </div>
    </div>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modernizr.custom.13711.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/count-to.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootsnav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/intlTelInput.js')); ?>"></script>

    <script>
        var input = document.querySelector('#phone');
        var countryCodeSpan = document.querySelector('#country-code');
        var countryNameInput = document.querySelector('#country-name');
        var iti = window.intlTelInput(input, {});

        updatePhoneNumber(); // Set initial phone number

        input.addEventListener('input', function() {
            // Check if the entered number starts with the selected country code
            if (!input.value.startsWith('+' + iti.getSelectedCountryData().dialCode)) {
                updatePhoneNumber();
            }
        });

        input.addEventListener('countrychange', function() {
            updateCountryCode();
            updateCountryName();
        });

        function updateCountryCode() {
            var selectedCountryData = iti.getSelectedCountryData();
            countryCodeSpan.textContent = '+' + selectedCountryData.dialCode;
        }

        function updateCountryName() {
            var selectedCountryData = iti.getSelectedCountryData();
            countryNameInput.value = selectedCountryData.name;
        }

        function updatePhoneNumber() {
            var phoneNumber = input.value.replace(/\D/g, ''); // Remove non-numeric characters
            var selectedCountryData = iti.getSelectedCountryData();
            input.value = '+' + selectedCountryData.dialCode + phoneNumber;
        }
    </script>

<script>
    var emailInput = document.getElementById('email');
    var emailError = document.getElementById('emailError');
    var websiteInput = document.getElementById('companyWebsite');
    var websiteError = document.getElementById('websiteError');

    emailInput.addEventListener('input', function() {
        validateEmail();
    });

    websiteInput.addEventListener('input', function() {
        validateWebsite();
    });

    function validateForm() {
        validateEmail();
        validateWebsite();
        // Add additional validation logic if needed
    }

    function validateEmail() {
        // Regular expression for an email ID excluding gmail.com and yahoo.com
        var emailRegex =
            /^[a-zA-Z0-9._%+-]+@(?!gmail\.com|yahoo\.com|outlook\.com|zoho\.com|protonmail\.com|mail\.com|gmx\.com|yandex\.com|aol\.com|tutanota\.com)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (emailRegex.test(emailInput.value)) {
            // Valid email
            emailError.textContent = '';
        } else {
            // Invalid email
            emailError.textContent = 'Please enter a valid professional email address.';
        }
    }

    function validateWebsite() {
        // Regular expression for a basic website URL
        var websiteRegex = /^(http(s)?:\/\/)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\S*)?$/;

        if (websiteRegex.test(websiteInput.value)) {
            // Valid website
            websiteError.textContent = '';
        } else {
            // Invalid website
            websiteError.textContent = 'Please enter a valid website URL';
        }
    }
    </script>

</body>

</html><?php /**PATH C:\xampp\htdocs\CivitBUILD\new-backup\resources\views/thankyou.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">


<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="Purpose-built Integrated Construction Project Management Software For Builders, Contractors and Owners | CivitBuild - Construction ERP Software">

    <!-- ========== Page Title ========== -->
    <title>Construction Project Management Software For Owners, Builders and Contractors</title>

    <base href="<?php echo e(asset('public')); ?>/">

    <!-- ========== Favicon Icon ========== -->
    <!-- <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon"> -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/favicon_io/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/favicon_io/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/favicon_io/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/favicon_io/site.webmanifest')); ?>">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/elegant-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/flaticon-set.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/bootsnav.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">

</head>

<body>

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Header 
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-fixed dark no-background bootsnav">

            <div class="container-fill">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav button">
                    <ul>
                        <li>
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#myModal">Enquire
                                Now</a>
                            <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                                Open modal
                            </button> -->
                        </li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->



                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars" style="color:#ffff;"></i>
                    </button>
                    <a class="navbar-brand" href="/">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" class="logo logo-display" alt="Logo">
                        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" class="logo logo-scrolled" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="#" data-out="#">
                        <li class="dropdown dropdown-right">
                            <a href="#home" class="smooth-menu">Home</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#Features">Features</a>
                        </li>
                        <li>
                            <a class="smooth-menu" href="#Who-use-CivitBUILD">Who use CivitBUILD</a>
                        </li>
                        
                        <li>
                            <a class="smooth-menu" href="#Why-CivitBUILD">Why CivitBUILD</a>
                        </li>

                        <li>
                            <a class="smooth-menu" href="#reviews">Reviews</a>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>
        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->

    <!-- Start Banner 
    ============================================= -->
    <div
        class="banner-area with-carousel bg-gray-responsive overflow-inherit content-double transparent-nav text-large">
        <!-- Fixed Shape -->
        <div class="fixed-shape" style="background-image: url(assets/img/shape/4.png);"></div>
        <!-- Fixed Shape -->
        <div class="box-table">
            <div class="box-cell">
                <div class="container">
                    <div class="double-items">
                        <div class="row align-center">
                            <div class="col-lg-6 left-info simple-video">
                                <div class="content" data-animation="animated fadeInUpBig">
                                    <!-- <h1>We're building <span>software</span> for you</h1> -->
                                    <!-- <h1 class="banner-heading">#1 ERP Software For <span>Contractors</span> &
                                        <span>Construction</span> Industry
                                    </h1> -->
                                    <h1 class="banner-heading" style="font-weight:600;">Save <span>3X time</span> -
                                        Fastest Contracting & Construction ERP Software</h1>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="box-shadow">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/save-time.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0; color:#0070bc;"><strong>Time saving
                                                            </strong></p>
                                                        <p style="margin:0;">3X faster project management</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="box-shadow">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/cubes.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0; color:#0070bc;"><strong>16+ Modules
                                                            </strong></p>
                                                        <p style="margin:0;">All project needs in one place</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row lg-pad">
                                        <div class="col-lg-6">
                                            <div class="box-shadow">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/customize.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0;color:#0070bc;"><strong>Customizable
                                                            </strong></p>
                                                        <p style="margin:0;">Customize CivitBUILD according to your
                                                            needs</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="box-shadow">
                                                <div class="row">
                                                    <div class="col-3">
                                                        <div class="hero-icon-img">
                                                            <img src="<?php echo e(asset('assets/img/icon/ownership.png')); ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="col-9">
                                                        <p style="margin:0; color:#0070bc;"><strong>Access From Anywhere
                                                            </strong></p>
                                                        <p style="margin:0;">Access Multiple sites from multiple devices
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="hero-form">
                                    <h3 class="text-white text-center">Book a Demo Now!</h3>
                                    <form action="<?php echo e(route('enquires')); ?>" method="POST" class="contact-form">
                                    <?php echo csrf_field(); ?>

                                    <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="name" name="name"
                                                        placeholder="Full Name" type="text" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="designation" name="designation"
                                                        placeholder="Designation" type="text" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="email" name="email"
                                                        placeholder="Corporate Email ID" type="email" required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-lg-5">
                                                            <div class="input-group-prepend">
                                                                <select class="custom-select" id="countryCode" name="countryCode"
                                                                    style="height: 50px;" required>
                                                                    <option data-countrycode="AE" selected value="+971">
                                                                        UAE (+971)
                                                                    </option>

                                                                    <option data-countrycode="DZ" value="+213">Algeria
                                                                        (+213)
                                                                    </option>
                                                                    <option data-countrycode="AD" value="+376">Andorra
                                                                        (+376)
                                                                    </option>
                                                                    <option data-countrycode="AO" value="+244">Angola
                                                                        (+244)
                                                                    </option>
                                                                    <option data-countrycode="AI" value="+1264">Anguilla
                                                                        (+1264)
                                                                    </option>
                                                                    <option data-countrycode="AG" value="+1268">Antigua
                                                                        &amp;
                                                                        Barbuda (+1268)</option>
                                                                    <option data-countrycode="AR" value="+54">Argentina
                                                                        (+54)
                                                                    </option>
                                                                    <option data-countrycode="AM" value="+374">Armenia
                                                                        (+374)
                                                                    </option>
                                                                    <option data-countrycode="AW" value="+297">Aruba
                                                                        (+297)
                                                                    </option>
                                                                    <option data-countrycode="AU" value="+61">Australia
                                                                        (+61)
                                                                    </option>
                                                                    <option data-countrycode="AT" value="+43">Austria
                                                                        (+43)
                                                                    </option>
                                                                    <option data-countrycode="AZ" value="+994">Azerbaijan
                                                                        (+994)
                                                                    </option>
                                                                    <option data-countrycode="BS" value="+1242">Bahamas
                                                                        (+1242)
                                                                    </option>
                                                                    <option data-countrycode="BH" value="+973">Bahrain
                                                                        (+973)
                                                                    </option>
                                                                    <option data-countrycode="BD" value="+880">Bangladesh
                                                                        (+880)
                                                                    </option>
                                                                    <option data-countrycode="BB" value="+1246">Barbados
                                                                        (+1246)
                                                                    </option>
                                                                    <option data-countrycode="BY" value="+375">Belarus
                                                                        (+375)
                                                                    </option>
                                                                    <option data-countrycode="BE" value="+32">Belgium
                                                                        (+32)
                                                                    </option>
                                                                    <option data-countrycode="BZ" value="+501">Belize
                                                                        (+501)
                                                                    </option>
                                                                    <option data-countrycode="BJ" value="+229">Benin
                                                                        (+229)
                                                                    </option>
                                                                    <option data-countrycode="BM" value="+1441">Bermuda
                                                                        (+1441)
                                                                    </option>
                                                                    <option data-countrycode="BT" value="+975">Bhutan
                                                                        (+975)
                                                                    </option>
                                                                    <option data-countrycode="BO" value="+591">Bolivia
                                                                        (+591)
                                                                    </option>
                                                                    <option data-countrycode="BA" value="+387">Bosnia
                                                                        Herzegovina
                                                                        (+387)</option>
                                                                    <option data-countrycode="BW" value="+267">Botswana
                                                                        (+267)
                                                                    </option>
                                                                    <option data-countrycode="BR" value="+55">Brazil
                                                                        (+55)
                                                                    </option>
                                                                    <option data-countrycode="BN" value="+673">Brunei
                                                                        (+673)
                                                                    </option>
                                                                    <option data-countrycode="BG" value="+359">Bulgaria
                                                                        (+359)
                                                                    </option>
                                                                    <option data-countrycode="BF" value="+226">Burkina
                                                                        Faso
                                                                        (+226)</option>
                                                                    <option data-countrycode="BI" value="+257">Burundi
                                                                        (+257)
                                                                    </option>
                                                                    <option data-countrycode="KH" value="+855">Cambodia
                                                                        (+855)
                                                                    </option>
                                                                    <option data-countrycode="CM" value="+237">Cameroon
                                                                        (+237)
                                                                    </option>
                                                                    <option data-countrycode="CA" value="+1">Canada (+1)
                                                                    </option>
                                                                    <option data-countrycode="CV" value="+238">Cape Verde
                                                                        Islands
                                                                        (+238)</option>
                                                                    <option data-countrycode="KY" value="+1345">Cayman
                                                                        Islands
                                                                        (+1345)</option>
                                                                    <option data-countrycode="CF" value="+236">Central
                                                                        African
                                                                        Republic (+236)</option>
                                                                    <option data-countrycode="CL" value="+56">Chile (+56)
                                                                    </option>
                                                                    <option data-countrycode="CN" value="+86">China (+86)
                                                                    </option>
                                                                    <option data-countrycode="CO" value="+57">Colombia
                                                                        (+57)
                                                                    </option>
                                                                    <option data-countrycode="KM" value="+269">Comoros
                                                                        (+269)
                                                                    </option>
                                                                    <option data-countrycode="CG" value="+242">Congo
                                                                        (+242)
                                                                    </option>
                                                                    <option data-countrycode="CK" value="+682">Cook
                                                                        Islands
                                                                        (+682)</option>
                                                                    <option data-countrycode="CR" value="+506">Costa Rica
                                                                        (+506)
                                                                    </option>
                                                                    <option data-countrycode="HR" value="+385">Croatia
                                                                        (+385)
                                                                    </option>
                                                                    <option data-countrycode="CU" value="+53">Cuba (+53)
                                                                    </option>
                                                                    <option data-countrycode="CY" value="+90392">Cyprus
                                                                        North
                                                                        (+90392)</option>
                                                                    <option data-countrycode="CY" value="+357">Cyprus
                                                                        South
                                                                        (+357)</option>
                                                                    <option data-countrycode="CZ" value="+42">Czech
                                                                        Republic
                                                                        (+42)</option>
                                                                    <option data-countrycode="DK" value="+45">Denmark
                                                                        (+45)
                                                                    </option>
                                                                    <option data-countrycode="DJ" value="+253">Djibouti
                                                                        (+253)
                                                                    </option>
                                                                    <option data-countrycode="DM" value="+1809">Dominica
                                                                        (+1809)
                                                                    </option>
                                                                    <option data-countrycode="DO" value="+1809">Dominican
                                                                        Republic (+1809)</option>
                                                                    <option data-countrycode="EC" value="+593">Ecuador
                                                                        (+593)
                                                                    </option>
                                                                    <option data-countrycode="EG" value="+20">Egypt (+20)
                                                                    </option>
                                                                    <option data-countrycode="SV" value="+503">El
                                                                        Salvador (+503)
                                                                    </option>
                                                                    <option data-countrycode="GQ" value="+240">Equatorial
                                                                        Guinea
                                                                        (+240)</option>
                                                                    <option data-countrycode="ER" value="+291">Eritrea
                                                                        (+291)
                                                                    </option>
                                                                    <option data-countrycode="EE" value="+372">Estonia
                                                                        (+372)
                                                                    </option>
                                                                    <option data-countrycode="ET" value="+251">Ethiopia
                                                                        (+251)
                                                                    </option>
                                                                    <option data-countrycode="FK" value="+500">Falkland
                                                                        Islands
                                                                        (+500)</option>
                                                                    <option data-countrycode="FO" value="+298">Faroe
                                                                        Islands
                                                                        (+298)</option>
                                                                    <option data-countrycode="FJ" value="+679">Fiji
                                                                        (+679)
                                                                    </option>
                                                                    <option data-countrycode="FI" value="+358">Finland
                                                                        (+358)
                                                                    </option>
                                                                    <option data-countrycode="FR" value="+33">France
                                                                        (+33)
                                                                    </option>
                                                                    <option data-countrycode="GF" value="+594">French
                                                                        Guiana
                                                                        (+594)</option>
                                                                    <option data-countrycode="PF" value="+689">French
                                                                        Polynesia
                                                                        (+689)</option>
                                                                    <option data-countrycode="GA" value="+241">Gabon
                                                                        (+241)
                                                                    </option>
                                                                    <option data-countrycode="GM" value="+220">Gambia
                                                                        (+220)
                                                                    </option>
                                                                    <option data-countrycode="GE" value="+7880">Georgia
                                                                        (+7880)
                                                                    </option>
                                                                    <option data-countrycode="DE" value="+49">Germany
                                                                        (+49)
                                                                    </option>
                                                                    <option data-countrycode="GH" value="+233">Ghana
                                                                        (+233)
                                                                    </option>
                                                                    <option data-countrycode="GI" value="+350">Gibraltar
                                                                        (+350)
                                                                    </option>
                                                                    <option data-countrycode="GR" value="+30">Greece
                                                                        (+30)
                                                                    </option>
                                                                    <option data-countrycode="GL" value="+299">Greenland
                                                                        (+299)
                                                                    </option>
                                                                    <option data-countrycode="GD" value="+1473">Grenada
                                                                        (+1473)
                                                                    </option>
                                                                    <option data-countrycode="GP" value="+590">Guadeloupe
                                                                        (+590)
                                                                    </option>
                                                                    <option data-countrycode="GU" value="+671">Guam
                                                                        (+671)
                                                                    </option>
                                                                    <option data-countrycode="GT" value="+502">Guatemala
                                                                        (+502)
                                                                    </option>
                                                                    <option data-countrycode="GN" value="+224">Guinea
                                                                        (+224)
                                                                    </option>
                                                                    <option data-countrycode="GW" value="+245">Guinea -
                                                                        Bissau
                                                                        (+245)</option>
                                                                    <option data-countrycode="GY" value="+592">Guyana
                                                                        (+592)
                                                                    </option>
                                                                    <option data-countrycode="HT" value="+509">Haiti
                                                                        (+509)
                                                                    </option>
                                                                    <option data-countrycode="HN" value="+504">Honduras
                                                                        (+504)
                                                                    </option>
                                                                    <option data-countrycode="HK" value="+852">Hong Kong
                                                                        (+852)
                                                                    </option>
                                                                    <option data-countrycode="HU" value="+36">Hungary
                                                                        (+36)
                                                                    </option>
                                                                    <option data-countrycode="IS" value="+354">Iceland
                                                                        (+354)
                                                                    </option>
                                                                    <option data-countrycode="ID" value="+62">Indonesia
                                                                        (+62)

                                                                    <option data-countrycode="IN" value="+91">India (+91)
                                                                    </option>
                                                                    </option>
                                                                    <option data-countrycode="IR" value="+98">Iran (+98)
                                                                    </option>
                                                                    <option data-countrycode="IQ" value="+964">Iraq
                                                                        (+964)
                                                                    </option>
                                                                    <option data-countrycode="IE" value="+353">Ireland
                                                                        (+353)
                                                                    </option>
                                                                    <option data-countrycode="IL" value="+972">Israel
                                                                        (+972)
                                                                    </option>
                                                                    <option data-countrycode="IT" value="+39">Italy (+39)
                                                                    </option>
                                                                    <option data-countrycode="JM" value="+1876">Jamaica
                                                                        (+1876)
                                                                    </option>
                                                                    <option data-countrycode="JP" value="+81">Japan (+81)
                                                                    </option>
                                                                    <option data-countrycode="JO" value="+962">Jordan
                                                                        (+962)
                                                                    </option>
                                                                    <option data-countrycode="KZ" value="+7">Kazakhstan
                                                                        (+7)
                                                                    </option>
                                                                    <option data-countrycode="KE" value="+254">Kenya
                                                                        (+254)
                                                                    </option>
                                                                    <option data-countrycode="KI" value="+686">Kiribati
                                                                        (+686)
                                                                    </option>
                                                                    <option data-countrycode="KP" value="+850">Korea
                                                                        North (+850)
                                                                    </option>
                                                                    <option data-countrycode="KR" value="+82">Korea South
                                                                        (+82)
                                                                    </option>
                                                                    <option data-countrycode="KW" value="+965">Kuwait
                                                                        (+965)
                                                                    </option>
                                                                    <option data-countrycode="KG" value="+996">Kyrgyzstan
                                                                        (+996)
                                                                    </option>
                                                                    <option data-countrycode="LA" value="+856">Laos
                                                                        (+856)
                                                                    </option>
                                                                    <option data-countrycode="LV" value="+371">Latvia
                                                                        (+371)
                                                                    </option>
                                                                    <option data-countrycode="LB" value="+961">Lebanon
                                                                        (+961)
                                                                    </option>
                                                                    <option data-countrycode="LS" value="+266">Lesotho
                                                                        (+266)
                                                                    </option>
                                                                    <option data-countrycode="LR" value="+231">Liberia
                                                                        (+231)
                                                                    </option>
                                                                    <option data-countrycode="LY" value="+218">Libya
                                                                        (+218)
                                                                    </option>
                                                                    <option data-countrycode="LI" value="+417">
                                                                        Liechtenstein
                                                                        (+417)</option>
                                                                    <option data-countrycode="LT" value="+370">Lithuania
                                                                        (+370)
                                                                    </option>
                                                                    <option data-countrycode="LU" value="+352">Luxembourg
                                                                        (+352)
                                                                    </option>
                                                                    <option data-countrycode="MO" value="+853">Macao
                                                                        (+853)
                                                                    </option>
                                                                    <option data-countrycode="MK" value="+389">Macedonia
                                                                        (+389)
                                                                    </option>
                                                                    <option data-countrycode="MG" value="+261">Madagascar
                                                                        (+261)
                                                                    </option>
                                                                    <option data-countrycode="MW" value="+265">Malawi
                                                                        (+265)
                                                                    </option>
                                                                    <option data-countrycode="MY" value="+60">Malaysia
                                                                        (+60)
                                                                    </option>
                                                                    <option data-countrycode="MV" value="+960">Maldives
                                                                        (+960)
                                                                    </option>
                                                                    <option data-countrycode="ML" value="+223">Mali
                                                                        (+223)
                                                                    </option>
                                                                    <option data-countrycode="MT" value="+356">Malta
                                                                        (+356)
                                                                    </option>
                                                                    <option data-countrycode="MH" value="+692">Marshall
                                                                        Islands
                                                                        (+692)</option>
                                                                    <option data-countrycode="MQ" value="+596">Martinique
                                                                        (+596)
                                                                    </option>
                                                                    <option data-countrycode="MR" value="+222">Mauritania
                                                                        (+222)
                                                                    </option>
                                                                    <option data-countrycode="YT" value="+269">Mayotte
                                                                        (+269)
                                                                    </option>
                                                                    <option data-countrycode="MX" value="+52">Mexico
                                                                        (+52)
                                                                    </option>
                                                                    <option data-countrycode="FM" value="+691">Micronesia
                                                                        (+691)
                                                                    </option>
                                                                    <option data-countrycode="MD" value="+373">Moldova
                                                                        (+373)
                                                                    </option>
                                                                    <option data-countrycode="MC" value="+377">Monaco
                                                                        (+377)
                                                                    </option>
                                                                    <option data-countrycode="MN" value="+976">Mongolia
                                                                        (+976)
                                                                    </option>
                                                                    <option data-countrycode="MS" value="+1664">
                                                                        Montserrat
                                                                        (+1664)</option>
                                                                    <option data-countrycode="MA" value="+212">Morocco
                                                                        (+212)
                                                                    </option>
                                                                    <option data-countrycode="MZ" value="+258">Mozambique
                                                                        (+258)
                                                                    </option>
                                                                    <option data-countrycode="MN" value="+95">Myanmar
                                                                        (+95)
                                                                    </option>
                                                                    <option data-countrycode="NA" value="+264">Namibia
                                                                        (+264)
                                                                    </option>
                                                                    <option data-countrycode="NR" value="+674">Nauru
                                                                        (+674)
                                                                    </option>
                                                                    <option data-countrycode="NP" value="+977">Nepal
                                                                        (+977)
                                                                    </option>
                                                                    <option data-countrycode="NL" value="+31">Netherlands
                                                                        (+31)
                                                                    </option>
                                                                    <option data-countrycode="NC" value="+687">New
                                                                        Caledonia
                                                                        (+687)</option>
                                                                    <option data-countrycode="NZ" value="+64">New Zealand
                                                                        (+64)
                                                                    </option>
                                                                    <option data-countrycode="NI" value="+505">Nicaragua
                                                                        (+505)
                                                                    </option>
                                                                    <option data-countrycode="NE" value="+227">Niger
                                                                        (+227)
                                                                    </option>
                                                                    <option data-countrycode="NG" value="+234">Nigeria
                                                                        (+234)
                                                                    </option>
                                                                    <option data-countrycode="NU" value="+683">Niue
                                                                        (+683)
                                                                    </option>
                                                                    <option data-countrycode="NF" value="+672">Norfolk
                                                                        Islands
                                                                        (+672)</option>
                                                                    <option data-countrycode="NP" value="+670">Northern
                                                                        Marianas
                                                                        (+670)</option>
                                                                    <option data-countrycode="NO" value="+47">Norway
                                                                        (+47)
                                                                    </option>
                                                                    <option data-countrycode="OM" value="+968">Oman
                                                                        (+968)
                                                                    </option>
                                                                    <option data-countrycode="PW" value="+680">Palau
                                                                        (+680)
                                                                    </option>
                                                                    <option data-countrycode="PA" value="+507">Panama
                                                                        (+507)
                                                                    </option>
                                                                    <option data-countrycode="PG" value="+675">Papua New
                                                                        Guinea
                                                                        (+675)</option>
                                                                    <option data-countrycode="PY" value="+595">Paraguay
                                                                        (+595)
                                                                    </option>
                                                                    <option data-countrycode="PE" value="+51">Peru (+51)
                                                                    </option>
                                                                    <option data-countrycode="PH" value="+63">Philippines
                                                                        (+63)
                                                                    </option>
                                                                    <option data-countrycode="PL" value="+48">Poland
                                                                        (+48)
                                                                    </option>
                                                                    <option data-countrycode="PT" value="+351">Portugal
                                                                        (+351)
                                                                    </option>
                                                                    <option data-countrycode="PR" value="+1787">Puerto
                                                                        Rico
                                                                        (+1787)</option>
                                                                    <option data-countrycode="QA" value="+974">Qatar
                                                                        (+974)
                                                                    </option>
                                                                    <option data-countrycode="RE" value="+262">Reunion
                                                                        (+262)
                                                                    </option>
                                                                    <option data-countrycode="RO" value="+40">Romania
                                                                        (+40)
                                                                    </option>
                                                                    <option data-countrycode="RU" value="+7">Russia (+7)
                                                                    </option>
                                                                    <option data-countrycode="RW" value="+250">Rwanda
                                                                        (+250)
                                                                    </option>
                                                                    <option data-countrycode="SM" value="+378">San Marino
                                                                        (+378)
                                                                    </option>
                                                                    <option data-countrycode="ST" value="+239">Sao Tome
                                                                        &amp;
                                                                        Principe (+239)</option>
                                                                    <option data-countrycode="SA" value="+966">Saudi
                                                                        Arabia
                                                                        (+966)</option>
                                                                    <option data-countrycode="SN" value="+221">Senegal
                                                                        (+221)
                                                                    </option>
                                                                    <option data-countrycode="CS" value="+381">Serbia
                                                                        (+381)
                                                                    </option>
                                                                    <option data-countrycode="SC" value="+248">Seychelles
                                                                        (+248)
                                                                    </option>
                                                                    <option data-countrycode="SL" value="+232">Sierra
                                                                        Leone
                                                                        (+232)</option>
                                                                    <option data-countrycode="SG" value="+65">Singapore
                                                                        (+65)
                                                                    </option>
                                                                    <option data-countrycode="SK" value="+421">Slovak
                                                                        Republic
                                                                        (+421)</option>
                                                                    <option data-countrycode="SI" value="+386">Slovenia
                                                                        (+386)
                                                                    </option>
                                                                    <option data-countrycode="SB" value="+677">Solomon
                                                                        Islands
                                                                        (+677)</option>
                                                                    <option data-countrycode="SO" value="+252">Somalia
                                                                        (+252)
                                                                    </option>
                                                                    <option data-countrycode="ZA" value="+27">South
                                                                        Africa (+27)
                                                                    </option>
                                                                    <option data-countrycode="ES" value="+34">Spain (+34)
                                                                    </option>
                                                                    <option data-countrycode="LK" value="+94">Sri Lanka
                                                                        (+94)
                                                                    </option>
                                                                    <option data-countrycode="SH" value="+290">St. Helena
                                                                        (+290)
                                                                    </option>
                                                                    <option data-countrycode="KN" value="+1869">St. Kitts
                                                                        (+1869)
                                                                    </option>
                                                                    <option data-countrycode="SC" value="+1758">St. Lucia
                                                                        (+1758)
                                                                    </option>
                                                                    <option data-countrycode="SD" value="+249">Sudan
                                                                        (+249)
                                                                    </option>
                                                                    <option data-countrycode="SR" value="+597">Suriname
                                                                        (+597)
                                                                    </option>
                                                                    <option data-countrycode="SZ" value="+268">Swaziland
                                                                        (+268)
                                                                    </option>
                                                                    <option data-countrycode="SE" value="+46">Sweden
                                                                        (+46)
                                                                    </option>
                                                                    <option data-countrycode="CH" value="+41">Switzerland
                                                                        (+41)
                                                                    </option>
                                                                    <option data-countrycode="SI" value="+963">Syria
                                                                        (+963)
                                                                    </option>
                                                                    <option data-countrycode="TW" value="+886">Taiwan
                                                                        (+886)
                                                                    </option>
                                                                    <option data-countrycode="TJ" value="+7">Tajikstan
                                                                        (+7)
                                                                    </option>
                                                                    <option data-countrycode="TH" value="+66">Thailand
                                                                        (+66)
                                                                    </option>
                                                                    <option data-countrycode="TG" value="+228">Togo
                                                                        (+228)
                                                                    </option>
                                                                    <option data-countrycode="TO" value="+676">Tonga
                                                                        (+676)
                                                                    </option>
                                                                    <option data-countrycode="TN" value="+216">Tunisia
                                                                        (+216)
                                                                    </option>
                                                                    <option data-countrycode="TR" value="+90">Turkey
                                                                        (+90)
                                                                    </option>
                                                                    <option data-countrycode="TM" value="+7">Turkmenistan
                                                                        (+7)
                                                                    </option>
                                                                    <option data-countrycode="TM" value="+993">
                                                                        Turkmenistan
                                                                        (+993)</option>
                                                                    <option data-countrycode="TV" value="+688">Tuvalu
                                                                        (+688)
                                                                    </option>
                                                                    <option data-countrycode="UG" value="+256">Uganda
                                                                        (+256)
                                                                    </option>
                                                                    <option data-countrycode="GB" value="+44">UK (+44)
                                                                    </option>
                                                                    <option data-countrycode="UA" value="+380">Ukraine
                                                                        (+380)
                                                                    </option>

                                                                    <option data-countrycode="UY" value="+598">Uruguay
                                                                        (+598)
                                                                    </option>
                                                                    <option data-countrycode="US" value="+1">USA (+1)
                                                                    </option>
                                                                    <option data-countrycode="UZ" value="+7">Uzbekistan
                                                                        (+7)
                                                                    </option>
                                                                    <option data-countrycode="VU" value="+678">Vanuatu
                                                                        (+678)
                                                                    </option>
                                                                    <option data-countrycode="VA" value="+379">Vatican
                                                                        City
                                                                        (+379)</option>
                                                                    <option data-countrycode="VE" value="+58">Venezuela
                                                                        (+58)
                                                                    </option>
                                                                    <option data-countrycode="VN" value="+84">Vietnam
                                                                        (+84)
                                                                    </option>
                                                                    <option data-countrycode="VI" value="+84">Virgin
                                                                        Islands - US
                                                                        (+1340)</option>
                                                                    <option data-countrycode="YE" value="+969">Yemen
                                                                        (North)(+969)</option>
                                                                    <option data-countrycode="YE" value="+967">Yemen
                                                                        (South)(+967)</option>
                                                                    <option data-countrycode="ZM" value="+260">Zambia
                                                                        (+260)
                                                                    </option>
                                                                    <option data-countrycode="ZW" value="+263">Zimbabwe
                                                                        (+263)
                                                                    </option>

                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 fp">
                                                            <input class="form-control" maxlength="10" minlength="10"
                                                                id="phone" name="phone" placeholder="Phone Number"
                                                                type="text" required>
                                                            <div id="phone-error" class="error-message"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="companyName" name="companyName"
                                                        placeholder="Company Name" type="text">
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="website" name="website"
                                                        placeholder="Company Website" type="text">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <select class="form-control" id="companyType" name="companyType"
                                                        style="height: 50px;" required>
                                                        <option disabled="" selected="" value="">Select Company Type
                                                        </option>
                                                        <option value="General Contractor">General Contractor</option>
                                                        <option value="Specialty Contractor">Specialty Contractor
                                                        </option>
                                                        <option value="Owner or Developer">Owner or Developer</option>
                                                        <option value="Government">Government</option>
                                                        <option value="Other">Other</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-group">
                                                    <input class="form-control" id="city" name="city" placeholder="City"
                                                        type="text">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group comments">
                                                    <textarea class="form-control" id="aboutProject" name="aboutProject"
                                                        placeholder="Tell Us About Project"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-lg-12" style="text-align:center;">
                                                <button type="submit" name="submit" id="submit"
                                                    class="contact-form-button">
                                                    Get a Free Demo Now
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wavesshape">
                    <img src="<?php echo e(asset('assets/img/waves-shape.svg')); ?>" alt="Shape">
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->

    <div class="productSec bg-gray" style="padding:50px 0px;" id="Features">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2>CivitBUILD Contracting ERP Software Has it All</h2>
                        <p>Streamline business process by CivitBUILD contracting & construction ERP software</p>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingTwo">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Bid Management
                                    </h4>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Create cost estimates for effective bidding
                                                    for contract projects.
                                                </li>
                                                <li class="service-li-list">Provide excel template for importing client
                                                    BOQ for quick
                                                    preparation of estimate.</li>

                                                <li class="service-li-list">Supports multi-currency of the resources for
                                                    preparing the estimate.
                                                </li>

                                                <li class="service-li-list">Provides Direct and Indirect cost estimate
                                                    of the project during the
                                                    bidding.</li>

                                                <li class="service-li-list">Maintains details of overhead and profits
                                                    considered in the Project.
                                                </li>

                                                <li class="service-li-list">Provides estimate revisions and maintains
                                                    history for of revision
                                                    for comparison.</li>

                                                <li class="service-li-list">Integrates the tender cost and quantity
                                                    during the project execution
                                                    for effective tracking and monitoring ensuring there is no cost
                                                    overrun and achieving targeted profit margins.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        Project Schedule Management
                                    </h4>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains project-wise activity calendar.
                                                </li>
                                                <li class="service-li-list">Maintains the Schedule Revisions.</li>
                                                <li class="service-li-list">Seamless integration with MS Project.</li>
                                                <li class="service-li-list">Integrates with Project Costing for tracking
                                                    the scope of work to be scheduled.</li>
                                                <li class="service-li-list">Maintains activity dependencies to auto
                                                    update the schedule.</li>
                                                <li class="service-li-list">Maintains the multiple baselines.</li>
                                                <li class="service-li-list">Provides Procurement Program for resources
                                                    for timely delivery.</li>
                                                <li class="service-li-list">Provides Cost Outflow based on scheduled
                                                    activity execution.</li>
                                                <li class="service-li-list">Tracks and Monitor Planned v/s Actual
                                                    Progress through Daily Progress update.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingFour">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                        Product Configuration
                                    </h4>
                                </div>
                                <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">User Configurable Work Flows.</li>
                                                <li class="service-li-list">Provides Company Configuration, Workflow
                                                    Templates and Alerts & Notification Templates.</li>
                                                <li class="service-li-list">Provides User Roles and Role based
                                                    Authorizations.</li>
                                                <li class="service-li-list">User Configurable Alerts and Notifications.
                                                </li>
                                                <li class="service-li-list">Maintains organization structure and
                                                    department details.</li>
                                                <li class="service-li-list">Maintains detailed employee information.
                                                </li>
                                                <li class="service-li-list">Multi-Currency and Localization settings.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingFive">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                        Project Cost Management
                                    </h4>
                                </div>
                                <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains the detailed Project Costing based
                                                    on the approved drawings and material specifications.</li>
                                                <li class="service-li-list">Integrates with Revit 3D model for
                                                    extracting the BOQ from the model file.</li>
                                                <li class="service-li-list">Maintains library of items with rate
                                                    analysis for quick generation of BOM.</li>
                                                <li class="service-li-list">Maintains Project Work Breakdown Structure
                                                    (WBS).</li>
                                                <li class="service-li-list">Supports multi-currency of the resources for
                                                    preparing the estimate.</li>
                                                <li class="service-li-list">Provides Direct and Indirect cost estimate
                                                    of the project during the bidding.</li>
                                                <li class="service-li-list">Plan, manage and track budget vs actual cost
                                                    for every project.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row service-pad">
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-6">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-6" aria-expanded="false" aria-controls="collapse-6">
                                        Inventory
                                    </h4>
                                </div>
                                <div id="collapse-6" class="collapse" aria-labelledby="heading-6"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Seamless integration with Procurement and
                                                    Accounts department.</li>
                                                <li class="service-li-list">Provides accounting effects based on the
                                                    material movements.</li>
                                                <li class="service-li-list">Maintains multiple project warehouses.</li>
                                                <li class="service-li-list">Provides Activity based resource issues.
                                                </li>
                                                <li class="service-li-list">Provides project-wise stock register and
                                                    stock valuation reports.</li>
                                                <li class="service-li-list">Allows stock transfers from one-project to
                                                    another.</li>
                                                <li class="service-li-list">Maintains Production log of resources like
                                                    ready mix concrete.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-7">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-7" aria-expanded="false" aria-controls="collapse-7">
                                        Mobility
                                    </h4>
                                </div>
                                <div id="collapse-7" class="collapse" aria-labelledby="heading-7"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Helps project team in reporting on field
                                                    activities such as Daily Progress Report (DPR), uploading project
                                                    progress photos, uploading MB, Material Requisition, etc.,</li>
                                                <li class="service-li-list">Helps stores team in uploading on site
                                                    transactions such as Purchase Requisition, MRN, GRN, Stock Transfer,
                                                    etc.,</li>
                                                <li class="service-li-list">Helps management team to approve the
                                                    Purchase Orders, Advance and Supplier Payment Certificates, etc., on
                                                    the move.</li>
                                                <li class="service-li-list">Helps sales team to post the on field
                                                    activities such as sales enquiries from the customers.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-8">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-8" aria-expanded="false" aria-controls="collapse-8">
                                        Sub-contractor Management
                                    </h4>
                                </div>
                                <div id="collapse-8" class="collapse" aria-labelledby="heading-8"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Supports Item Rate, Lumpsum and Built-up
                                                    area type of work orders.</li>
                                                <li class="service-li-list">Integrates with Project BOQ to control the
                                                    scope of work to be outsourced.</li>
                                                <li class="service-li-list">Tracks service requests by the project team,
                                                    enquiries floated, vendor quotations.</li>
                                                <li class="service-li-list">Provides analysis of vendor quotation
                                                    along-with sensitivity analysis.</li>
                                                <li class="service-li-list">Maintains details of work orders & its
                                                    amendments, payment terms, terms & conditions, retentions and
                                                    advance recovery settings.</li>
                                                <li class="service-li-list">Tracks work done by the contractor through
                                                    measurements entries and consider the same for bill processing.</li>
                                                <li class="service-li-list">Manages retention recoveries and advance
                                                    adjustments while processing the contractor work done bills.</li>
                                                <li class="service-li-list">Tracks work done v/s payment released to the
                                                    contractors.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-9">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-9" aria-expanded="false" aria-controls="collapse-8">
                                        Client Sales Billing
                                    </h4>
                                </div>
                                <div id="collapse-9" class="collapse" aria-labelledby="heading-9"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains and generate the Invoices against
                                                    the awarded tender as per the payment terms.</li>
                                                <li class="service-li-list">Seamless integration with Bid Management,
                                                    Project Execution and Accounts department to generate and posting of
                                                    the invoices.</li>
                                                <li class="service-li-list">Tracks Project Progress through Work Done
                                                    Measurements from Project Execution Department.</li>
                                                <li class="service-li-list">Generates Mobilization advance, Work done
                                                    and Material Advance Invoices.</li>
                                                <li class="service-li-list">Maintains Advance Adjustment and Retentions.
                                                </li>
                                                <li class="service-li-list">Provision to certify the bills from the
                                                    concerned authorities.</li>
                                                <li class="service-li-list">Identifies and tracks the variations and
                                                    price escalations.</li>
                                                <li class="service-li-list">Alerts based on the Agreed Payment Terms.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row service-pad">
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-10">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-10" aria-expanded="false" aria-controls="collapse-10">
                                        Project Monitoring & Control
                                    </h4>
                                </div>
                                <div id="collapse-10" class="collapse" aria-labelledby="heading-10"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Safeguard your projects from schedule and
                                                    cost overruns through 360 degree monitoring and unprecedented
                                                    control over your projects.</li>
                                                <li class="service-li-list">Tracks actual cost against budgeted cost of
                                                    the project.</li>
                                                <li class="service-li-list">Assigns project activities to the project
                                                    team and tracks its execution.</li>
                                                <li class="service-li-list">Records work measurements through daily
                                                    reports to update the project progress.</li>
                                                <li class="service-li-list">Generates activity based material
                                                    requisitions for project work execution.</li>
                                                <li class="service-li-list">Verifies and controls the resource
                                                    requisition quantity against the budgeted quantity.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-11">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-11" aria-expanded="false" aria-controls="collapse-11">
                                        Procurement
                                    </h4>
                                </div>
                                <div id="collapse-11" class="collapse" aria-labelledby="heading-11"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Helps in procuring the right resource at
                                                    right time and at right price.</li>
                                                <li class="service-li-list">Supports multi-currency for import
                                                    purchases.</li>
                                                <li class="service-li-list">Seamless integration with Project, Stores
                                                    and Accounts departments.</li>
                                                <li class="service-li-list">Tracks project-wise purchases.</li>
                                                <li class="service-li-list">Maintains history of vendors and their rates
                                                    for analysis and procuring the resources from the right source.</li>
                                                <li class="service-li-list">Maintains taxes & duties details applicable
                                                    for the projects.</li>
                                                <li class="service-li-list">Accumulates purchase requests of multiple
                                                    projects for bulk purchasing.</li>
                                                <li class="service-li-list">Provides analysis of supplier quotations for
                                                    effective purchase.</li>
                                                <li class="service-li-list">Generates Purchase Orders based on project
                                                    requirements with detailed terms & conditions.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-12">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-12" aria-expanded="false" aria-controls="collapse-12">
                                        Sales & CRM
                                    </h4>
                                </div>
                                <div id="collapse-12" class="collapse" aria-labelledby="heading-12"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Provides dashboards for enquiry recording
                                                    and follow-up.</li>
                                                <li class="service-li-list">Provides dashboards for Enquiry Analysis,
                                                    Booking Analysis, Outstanding Analysis, Collection Analysis.</li>
                                                <li class="service-li-list">Maintain project-wise enquiries and provides
                                                    analysis report on customer requirements.</li>
                                                <li class="service-li-list">Maintains project-wise unit details, rate
                                                    list and payment schedules.</li>
                                                <li class="service-li-list">Maintains the Booking information, Account
                                                    Status, Payment Receipts, etc.</li>
                                                <li class="service-li-list">Provision to calculate Interests for delayed
                                                    payment.</li>
                                                <li class="service-li-list">Provision to generate booking forms along
                                                    with payment schedule.</li>
                                                <li class="service-li-list">Auto generates demand letters based on
                                                    completion project milestone.</li>
                                                <li class="service-li-list">Generates letters like Payment Reminder,
                                                    Welcome Letter, Thanking Letter, Allotment Letter, Bank NOC etc.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-13">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-13" aria-expanded="false" aria-controls="collapse-13">
                                        Financial Accounting
                                    </h4>
                                </div>
                                <div id="collapse-13" class="collapse" aria-labelledby="heading-13"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains global chart of accounts.</li>
                                                <li class="service-li-list">Supports multi-currency transactions.</li>
                                                <li class="service-li-list">Maintains customized cost centers.</li>
                                                <li class="service-li-list">Integrates with Subcontracting and
                                                    Procurement department for posting and payment of vendor invoices.
                                                </li>
                                                <li class="service-li-list">Integrates with Sales and Client Billing
                                                    department for Posting Invoices and payment receipts.</li>
                                                <li class="service-li-list">Provides Bank/ Cash - Payments/ Receipts,
                                                    Journal Vouchers, Debit Note, Credit Note, Bank Reconciliation,
                                                    Cheque Printing and Year End Finalization.</li>
                                                <li class="service-li-list">Provides project-wise MIS reports.</li>
                                                <li class="service-li-list">Integration with Tally.</li>
                                                <li class="service-li-list">Generates Project-wise Balance Sheet, Profit
                                                    & Loss and Trial Balance Reports.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row service-pad">
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-14">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-14" aria-expanded="false" aria-controls="collapse-14">
                                        Dashboard
                                    </h4>
                                </div>
                                <div id="collapse-14" class="collapse" aria-labelledby="heading-14"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Provides user friendly analytical dashboards
                                                    for Real Estate Developers to track Lead Analysis, Payment
                                                    Collection & Outstanding Analysis, Sold v/s Available Inventory,
                                                    etc.,</li>
                                                <li class="service-li-list">Provides user friendly analytical dashboards
                                                    for Contractors to track Booking v/s Billing, Payment Collection &
                                                    Outstanding Analysis, Planned v/s Actual Cost, etc.,</li>
                                                <li class="service-li-list">Provides user friendly analytical dashboards
                                                    for analysis of Return v/s Marketing Spend, Lead Generation
                                                    Analysis, No. of Calls/ Meetings/ Visits to customer acquisition.
                                                </li>
                                                <li class="service-li-list">Provides user friendly analytical dashboards
                                                    for financial performance of the project.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-15">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-15" aria-expanded="false" aria-controls="collapse-15">
                                        Plant & Machinery Management
                                    </h4>
                                </div>
                                <div id="collapse-15" class="collapse" aria-labelledby="heading-15"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains the Technical, Insurance and
                                                    Maintenance details of PnM.</li>
                                                <li class="service-li-list">Integrates with Projects department for
                                                    allocation of PnM.</li>
                                                <li class="service-li-list">Provision to generate the Project Machinery
                                                    Requirements.</li>
                                                <li class="service-li-list">Tracks Availability and Make Allotments to
                                                    the required Projects.</li>
                                                <li class="service-li-list">Dispatch and Transport the machineries to
                                                    the required Project Site.</li>
                                                <li class="service-li-list">Maintain Daily Logs of utilization of PnM.
                                                </li>
                                                <li class="service-li-list">Monitors efficiency and utilization of PnM.
                                                </li>
                                                <li class="service-li-list">Maintains repair and maintenance details of
                                                    PnM.</li>
                                                <li class="service-li-list">Cannibalization of PnM.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header text-white" id="heading-16">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-16" aria-expanded="false" aria-controls="collapse-16">
                                        Fixed Asset
                                    </h4>
                                </div>
                                <div id="collapse-16" class="collapse" aria-labelledby="heading-16"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintain asset master / register.</li>
                                                <li class="service-li-list">Supports multi-currency.</li>
                                                <li class="service-li-list">Provision to convert resources to fixed
                                                    assets.</li>
                                                <li class="service-li-list">Depreciation calculation as per Company and
                                                    IT act.</li>
                                                <li class="service-li-list">Provision to change the rate of
                                                    depreciation.</li>
                                                <li class="service-li-list">Integrates with Accounts department for
                                                    posting asset depreciation.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="faq-content">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="heading-17">
                                    <h4 class="mb-0 collapsed text-white" data-toggle="collapse"
                                        data-target="#collapse-17" aria-expanded="false" aria-controls="collapse-17">
                                        Payroll
                                    </h4>
                                </div>
                                <div id="collapse-17" class="collapse" aria-labelledby="heading-17"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <div class="list-check">
                                            <ul style="list-style-type:disc;">
                                                <li class="service-li-list">Maintains Employee profiles in a structured
                                                    and standard format.</li>
                                                <li class="service-li-list">Integrates with biometric devices for
                                                    importing attendance.</li>
                                                <li class="service-li-list">Maintains project wise employee attendance.
                                                </li>
                                                <li class="service-li-list">Generates of Project-wise salary register.
                                                </li>
                                                <li class="service-li-list">Facility to submit Leave, Loan & Advance
                                                    applications to the concerned authorities for approval.</li>
                                                <li class="service-li-list">Provision to handle all allowances &
                                                    deductions.</li>
                                                <li class="service-li-list">Integration with Accounts department for
                                                    salary processing.</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start About 
    ============================================= -->
    <div id="Who-use-CivitBUILD" class="about-area default-padding" style="padding-top:10px;">
        <div class="container">
            <div class="row">
                <div class="about-items">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="about-content text-center">
                            <h2>CivitBUILD Contracting & Construction ERP software is made for </h2>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="top-features">
                            <div class="row">
                                <div class="col-lg-3 col-md-6 single-item">
                                    <div class="item" style="box-shadow: none;">
                                        <!-- <i class="flaticon-speech-bubble"></i> -->
                                        <img src="<?php echo e(asset('assets/img/icon/organization.png')); ?>" alt="organization"
                                            style="width: 70px;height: 70px;" />
                                        <h4> Companies in the contracting industry seeking to expand and enhance their
                                            business</h4>
                                        <hr style="padding-bottom:10px;">
                                        <p>
                                            Whether you're aiming to broaden your horizons, reach new heights, or simply
                                            shake things up, our solution is your key to building a thriving
                                            construction business on a solid foundation of success.

                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6 single-item">
                                    <div class="item" style="box-shadow: none;">
                                        <img src="<?php echo e(asset('assets/img/icon/software.png')); ?>" alt="organization"
                                            style="width: 70px;height: 70px;" />
                                        <h4>Contracting Companies use multiple software in their departments</h4>
                                        <hr style="padding-bottom:10px;">
                                        <p>
                                            Are you spending too much time gathering information from various sources
                                            such as Accounting, HR, procurement, project management, and document
                                            sharing applications?
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6 single-item">
                                    <div class="item" style="box-shadow: none;">
                                        <img src="<?php echo e(asset('assets/img/icon/building.png')); ?>" alt="organization"
                                            style="width: 70px;height: 70px;" />
                                        <h4>Established Contracting Companies</h4>
                                        <hr style="padding-bottom:10px;">
                                        <p>
                                            Our solution offers optimal advantages for Contracting and Construction
                                            firms managing simultaneous projects. It achieves this by optimizing current
                                            processes and eliminating communication gaps between project sites
                                        </p>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-6 single-item">
                                    <div class="item" style="box-shadow: none;">
                                        <img src="<?php echo e(asset('assets/img/icon/problem-solving.png')); ?>" alt="organization"
                                            style="width:75px;height:70px;" />
                                        <h4>Contracting Companies expanding to new fields & activities</h4>
                                        <hr style="padding-bottom:10px;">
                                        <p>
                                            Embarking on a new venture can pose its own set of challenges, and
                                            introducing changes to your existing systems concurrently can add an extra
                                            layer of difficulty.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About -->




    <!-- Start Features 
    ============================================= -->
    <div id="Why-CivitBUILD" class="bg-gray features-area default-padding bottom-small">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2>Why CivitBUILD Construction and Contracting ERP Software?</h2>
                        <p>
                            Enhance your productivity, streamline communication, and accelerate your project
                            development, all from a centralized, reliable source. Explore the extensive capabilities of
                            the premium construction management platform and discover how you can achieve more in less
                            time.
                        </p>
                    </div>
                </div>
            </div>
            <div class="features-items">
                <div class="row">
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <!-- <i class="flaticon-scroll"></i> -->
                                <img src="<?php echo e(asset('assets/img/icon/Process-Driven.png')); ?>" class="img-res" alt="Process Driven" />
                            </div>
                            <div class="info">

                                <h4>Process Driven</h4>

                                <p>
                                    Transforming construction with advanced ERP and project management solutions.
                                    Streamlining industry-standard processes for heightened efficiency and success in
                                    every project
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/Flexible-&-Customizable.png')); ?>" class="img-res"
                                    alt="Flexible & Customizable" />
                            </div>
                            <div class="info">
                                <h4>Flexible & Customizable</h4>
                                <p>
                                    CivitBuild offers customizable Construction ERP and Project Management software,
                                    tailored to your business needs. Streamline operations, enhance collaboration, and
                                    optimize efficiency with our innovative solutions..
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/Decision-Making-Tool.png')); ?>" class="img-res"
                                    alt="Decision Making Tool" />
                            </div>
                            <div class="info">
                                <h4>Decision Making Tool ​</h4>
                                <p>
                                    Smart decision-making with our construction ERP and project management software.
                                    Gain real-time insights through powerful business intelligence and intuitive
                                    dashboards, optimizing every aspect of your construction projects.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/Scalable.png')); ?>" class="img-res" alt="Scalable" />
                            </div>
                            <div class="info">
                                <h4>Scalable</h4>
                                <p>
                                    CivitBUILD contracting & construction ERP crafted to meet the growing demands of
                                    your expanding enterprise. Stay agile, streamline processes, and thrive in a dynamic
                                    construction market with CivitBuild
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/Access-Anywhere-Anytime​.png')); ?>" class="img-res"
                                    alt="Access Anywhere Anytime" />
                            </div>
                            <div class="info">
                                <h4>Access Anywhere Anytime​ </h4>
                                <p>
                                    Revolutionizing construction management with cloud-powered ERP and project
                                    solutions. Experience unparalleled mobility from anywhere, empowering seamless
                                    collaboration and project control.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 single-item">
                        <div class="item">
                            <div class="icon">
                                <img src="<?php echo e(asset('assets/img/icon/Futuristic.png')); ?>" class="img-res" alt="Futuristic" />
                            </div>
                            <div class="info">
                                <h4>Futuristic </h4>
                                <p>
                                    CivitBUILD project management software for the future. Stay ahead with innovative
                                    solutions tailored to embrace rapid technological change in the construction
                                    industry.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Features -->

    <!-- Start Overview 
    ============================================= -->
    <div id="overview" class="overview-area default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h2>Quick Software Overview</h2>
                        <p>
                            Experience streamlined business management with our ERP Software. Gain real-time insights,
                            automate workflows, and achieve unparalleled efficiency. Tailored for your success, it's the
                            future of ERP solutions.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 text-center overview-items">
                    <div class="overview-carousel owl-carousel owl-theme">
                        <img src="<?php echo e(asset('assets/img/app/Sales-CRM-Dashboard.png')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Dashboard.png')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Inventory-Dashboard.png')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Financial-Accounting.png')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Payroll.png')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Client-BOQ.png')); ?>" alt="Thumb">
                        <img src="<?php echo e(asset('assets/img/app/Login-Page.png')); ?>" alt="Thumb">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Overview -->


    <div id="strip" class="strip-section default-padding"
        style="background-image: url(<?php echo e(asset('assets/img/civit-bg.png' )); ?>); text-align:center">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center">
                        <h2 class="text-white">Integration Ready and Full Customizable Contracting and Construction ERP
                            Software </h2>
                        <p class="text-white">Your go-to solution for Construction ERP. Integration-ready and fully
                            customizable, our software streamlines project management with seamless integration and
                            personalized features. Boost efficiency, enhance collaboration, and stay agile in
                            construction with CivitBuild construction ERP.</p>
                    </div>
                </div>
            </div>
            <div class="row align-center">
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon1.png')); ?>" alt="" width="120px" height="120px" />
                        <p class="text-white strip-desc">Modular based for an easy pick-and-choose as per your unique
                            needs</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon2.png')); ?>" alt="" width="100px" height="100px" />
                        <p class="text-white strip-desc">Integrate with Tally Accounting Software</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon3.png')); ?>" alt="" width="100px" height="100px" />
                        <p class="text-white strip-desc">Integrates with Microsoft Project</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon4.png')); ?>" alt="" width="100px" height="100px" />
                        <p class="text-white strip-desc">Integrates with Microsoft Dynamics </p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon5.png')); ?>" alt="" width="100px" height="100px" />
                        <p class="text-white strip-desc">Integrates with Primavera Project Scheduling</p>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="content" data-animation="animated fadeInUpBig">
                        <img src="<?php echo e(asset('assets/img/icon/strip-icon6.png')); ?>" alt="" width="100px" height="100px" />
                        <p class="text-white strip-desc">Integrates fully with Rivet BIM to generate BOQ</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="banner-area video-section bg-gray text-center sticky-nav small-text bg-fixed">
        <div class="box-table">
            <div class="box-cell">
                <div class="container">
                    <div class="double-items">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="content" data-animation="animated fadeInUpBig">
                                    <h2 style="font-size:45px;">CivitBUILD <span>Advantage</span></h2>
                                    <p style="text-align:left;">CivitBuild is a construction management leader that provides a strong platform enhanced with customizable workflows, role-based access controls, and thorough organization oversight. CivitBuild prioritizes empowering efficiency and collaboration by ensuring seamless construction processes, from customized workflows to thorough organization management, thereby laying the groundwork for unmatched project success.</p>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="banner">
                                    <img src="<?php echo e(asset('assets/img/app/app-2.png')); ?>" alt="Thumb" style="height: 250px;">
                                    <div class="overlay">
                                        <a class="popup-youtube video-play-button" href="<?php echo e(asset('assets/video/CivitBUILD-Advantage.mp4')); ?>">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                    <!-- <video width="320" height="190" controls>
                                        <source src="<?php echo e(asset('assets/video/CivitBUILD-Advantage.mp4')); ?>" type="video/mp4">
                                    </video> -->
                                    <!-- <iframe class="embed-responsive embed-responsive-16by9" width="560" height="315"
                    src="https://www.youtube.com/embed/_1rZUpLBgjA" title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen></iframe> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Start Testimonials 
    ============================================= -->
    <div class="testimonials-area default-padding" id="reviews">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading single text-center">
                        <h2>Customer Review</h2>
                        <p>What outcomes did our clients attain through the implementation of CivitBUILD contracting and
                            construction ERP?</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div id="testimonial-slider" class="owl-carousel">
                                    <div class="testimonial">
                                        <p class="description">
                                            Soft Tech people know the construction business well. The product helped in
                                            interconnection our various project sites, departments, and office - which
                                            made MIS consolidation across organization quicker. Being a value-for-money
                                            proposition, we were able to generate a clear ROI on CivitBUILD
                                            implementation
                                        </p>

                                        <h3 class="title">Anil Bakeri</h3>
                                        <span class="post">Chairman & Managing Director</span>
                                    </div>
                                    <div class="testimonial">
                                        <p class="description">
                                            CivitBUILD has enhanced the efficiency and effectiveness of our Sop's
                                            through the integration and automation offered by the software. It's a well
                                            designed system that addresses the management cycle of construction projects
                                            skillfully. The SoftTech team did a super job throughout the training and
                                            implementation processes. Soft Tech indeed has a unique approach to
                                            attending to their customers business needs, which is a key to the success
                                            of any service business.
                                        </p>
                                        <h3 class="title">Dr. Samar Daham Hatoum</h3>
                                        <span class="post">General manager </span>
                                    </div>
                                    <div class="testimonial">
                                        <p class="description">
                                            It has been a great journey till now to be a part of the CivitBUILD Family.
                                            CivitBUILD has provided the solution of our pain points which we were
                                            suffering from last few years and due to the number of Projects were
                                            increasing it was not easy for us to manage everything from a common
                                            platform. CivitBUILD, we have much better control over our policies and
                                            procedures, our expenditures, and our forecasts. In addition, the CivitBUILD
                                            support team has done a wonderful job in guiding us through the
                                            implementation process and continues to provide us with outstanding support
                                            after the fact; also the response to tackling any reported issue is
                                            remarkable, this, in turn, concludes that CivitBUILD adopts the unique
                                            approach strategy to meet customers’ business needs, which in my opinion, is
                                            a key to the success of any service business. So SoftTech is definitely here
                                            to stay!
                                        </p>
                                        <h3 class="title">Mr. Anand Joshi</h3>
                                        <span class="post">Director (Civil) </span>
                                    </div>
                                    <div class="testimonial">
                                        <p class="description">
                                            Being a member of the CIVITBUILD family has been a fantastic experience thus
                                            far. CIVITBUILD has provided a solution to the pain points that we had been
                                            experiencing over the past few years, and it was becoming increasingly
                                            difficult for us to manage everything from a single platform as the number
                                            of projects grew. We have considerably better control over our policies and
                                            procedures, expenditures, and forecasts thanks to CivitBUILD. Furthermore,
                                            the CivitBUILD Implementation team & support team has done an outstanding
                                            job guiding us through the implementation process and continues to provide
                                            us with outstanding support after the fact; also, the response time to any
                                            reported issue is remarkable, which concludes that CivitBUILD uses a unique
                                            approach strategy to meet customers' business needs, which, in my opinion,
                                            is a key to any service business's success. SoftTech is unquestionably here
                                            to stay!
                                        </p>
                                        <h3 class="title">Mr. Parag Dnyandeo Patil</h3>
                                        <span class="post">Director (Civil)</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials -->


    <div class="col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-lg">
        <div class="container">
            <div class="col-lg-6 col-sm-6 col-xs-6 div-line pd0">
                <a href="tel:+971 50 383 4122" class="fix-link callme">
                    <i class="fa fa-phone f-icon" aria-hidden="true"></i> CALL NOW
                </a>
            </div>

            <div class="col-lg-6 col-sm-6 col-xs-6 pd0">
                <a href="javascript:void(0);" data-toggle="modal" data-target="#myModal"><button
                        class="btn1 fix-link i-am"><i class="fa fa-envelope"></i> ENQUIRE NOW</button></a>

                <!-- <button class="btn1 fix-link i-am"><i class="fa fa-envelope"></i> ENQUIRE NOW</button> -->
            </div>
        </div>
    </div>

    <div id="overview" class="overview-area bg-blue default-padding">
        <div class="container border-color card">
            <div class="double-items thumb-140">
                <div class="row align-center">
                    <div class="col-lg-8 left-info simple-video">
                        <div class="content" data-animation="animated fadeInUpBig">
                            <h5 style="font-weight: 900; color:#0070bc; font-size:18px; text-align: center;">Ready to
                                experience what <span>CivitBUILD</span> can do for your construction
                                business? Specially designed for UAE
                            </h5>
                        </div>
                    </div>
                    <div class="col-lg-4 right-info">
                        <a class="btn circle btn-theme-n border-n btn-md" href="javascript:void(0)" data-toggle="modal"
                            data-target="#myModal">Request a Demo</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Start Footer 
    ============================================= -->
    <footer class="bg-light">
        <div class="container">
            <!-- Start Footer Bottom -->
            <div class="footer-bottom">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-lg-6">
                            <p>&copy; Copyright <script type="text/javascript">
                                document.write(new Date().getFullYear());
                                </script>. All Rights Reserved.</a></p>
                        </div>
                        <div class="col-lg-6 text-right link">
                            <ul>
                                <li>
                                    <a href="tel: +97 15 0383 4122">+97 15 0383 4122</a>
                                </li>
                                <li>
                                    <a href="mailto: measales@thecivit.com">measales@thecivit.com</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Footer Bottom -->
        </div>
    </footer>
    <!-- End Footer -->

    <!-- Enquiry modal -->
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h3 class="modal-title">Enquire Now!</h3>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="contact-form">
                        <form action="<?php echo e(route('enquires')); ?>" method="POST" class="contact-form">
                        <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="name" name="name" placeholder="Full Name"
                                            type="text" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="designation" name="designation"
                                            placeholder="Designation" type="text" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="email" name="email"
                                            placeholder="Corporate Email ID" type="email" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-lg-5">
                                                <div class="input-group-prepend">
                                                    <select class="custom-select" name="countryCode" id="countryCode" style="height: 50px;"
                                                        required>
                                                        <!-- <option disabled="" selected="" value="">Country</option> -->
                                                        <option data-countrycode="AE" selected value="+971">UAE (+971)
                                                        </option>

                                                        <option data-countrycode="DZ" value="+213">Algeria (+213)
                                                        </option>
                                                        <option data-countrycode="AD" value="+376">Andorra (+376)
                                                        </option>
                                                        <option data-countrycode="AO" value="+244">Angola (+244)
                                                        </option>
                                                        <option data-countrycode="AI" value="+1264">Anguilla (+1264)
                                                        </option>
                                                        <option data-countrycode="AG" value="+1268">Antigua &amp;
                                                            Barbuda (+1268)</option>
                                                        <option data-countrycode="AR" value="+54">Argentina (+54)
                                                        </option>
                                                        <option data-countrycode="AM" value="+374">Armenia (+374)
                                                        </option>
                                                        <option data-countrycode="AW" value="+297">Aruba (+297)
                                                        </option>
                                                        <option data-countrycode="AU" value="+61">Australia (+61)
                                                        </option>
                                                        <option data-countrycode="AT" value="+43">Austria (+43)
                                                        </option>
                                                        <option data-countrycode="AZ" value="+994">Azerbaijan (+994)
                                                        </option>
                                                        <option data-countrycode="BS" value="+1242">Bahamas (+1242)
                                                        </option>
                                                        <option data-countrycode="BH" value="+973">Bahrain (+973)
                                                        </option>
                                                        <option data-countrycode="BD" value="+880">Bangladesh (+880)
                                                        </option>
                                                        <option data-countrycode="BB" value="+1246">Barbados (+1246)
                                                        </option>
                                                        <option data-countrycode="BY" value="+375">Belarus (+375)
                                                        </option>
                                                        <option data-countrycode="BE" value="+32">Belgium (+32)
                                                        </option>
                                                        <option data-countrycode="BZ" value="+501">Belize (+501)
                                                        </option>
                                                        <option data-countrycode="BJ" value="+229">Benin (+229)
                                                        </option>
                                                        <option data-countrycode="BM" value="+1441">Bermuda (+1441)
                                                        </option>
                                                        <option data-countrycode="BT" value="+975">Bhutan (+975)
                                                        </option>
                                                        <option data-countrycode="BO" value="+591">Bolivia (+591)
                                                        </option>
                                                        <option data-countrycode="BA" value="+387">Bosnia Herzegovina
                                                            (+387)</option>
                                                        <option data-countrycode="BW" value="+267">Botswana (+267)
                                                        </option>
                                                        <option data-countrycode="BR" value="+55">Brazil (+55)
                                                        </option>
                                                        <option data-countrycode="BN" value="+673">Brunei (+673)
                                                        </option>
                                                        <option data-countrycode="BG" value="+359">Bulgaria (+359)
                                                        </option>
                                                        <option data-countrycode="BF" value="+226">Burkina Faso
                                                            (+226)</option>
                                                        <option data-countrycode="BI" value="+257">Burundi (+257)
                                                        </option>
                                                        <option data-countrycode="KH" value="+855">Cambodia (+855)
                                                        </option>
                                                        <option data-countrycode="CM" value="+237">Cameroon (+237)
                                                        </option>
                                                        <option data-countrycode="CA" value="+1">Canada (+1)</option>
                                                        <option data-countrycode="CV" value="+238">Cape Verde Islands
                                                            (+238)</option>
                                                        <option data-countrycode="KY" value="+1345">Cayman Islands
                                                            (+1345)</option>
                                                        <option data-countrycode="CF" value="+236">Central African
                                                            Republic (+236)</option>
                                                        <option data-countrycode="CL" value="+56">Chile (+56)
                                                        </option>
                                                        <option data-countrycode="CN" value="+86">China (+86)
                                                        </option>
                                                        <option data-countrycode="CO" value="+57">Colombia (+57)
                                                        </option>
                                                        <option data-countrycode="KM" value="+269">Comoros (+269)
                                                        </option>
                                                        <option data-countrycode="CG" value="+242">Congo (+242)
                                                        </option>
                                                        <option data-countrycode="CK" value="+682">Cook Islands
                                                            (+682)</option>
                                                        <option data-countrycode="CR" value="+506">Costa Rica (+506)
                                                        </option>
                                                        <option data-countrycode="HR" value="+385">Croatia (+385)
                                                        </option>
                                                        <option data-countrycode="CU" value="+53">Cuba (+53)</option>
                                                        <option data-countrycode="CY" value="+90392">Cyprus North
                                                            (+90392)</option>
                                                        <option data-countrycode="CY" value="+357">Cyprus South
                                                            (+357)</option>
                                                        <option data-countrycode="CZ" value="+42">Czech Republic
                                                            (+42)</option>
                                                        <option data-countrycode="DK" value="+45">Denmark (+45)
                                                        </option>
                                                        <option data-countrycode="DJ" value="+253">Djibouti (+253)
                                                        </option>
                                                        <option data-countrycode="DM" value="+1809">Dominica (+1809)
                                                        </option>
                                                        <option data-countrycode="DO" value="+1809">Dominican
                                                            Republic (+1809)</option>
                                                        <option data-countrycode="EC" value="+593">Ecuador (+593)
                                                        </option>
                                                        <option data-countrycode="EG" value="+20">Egypt (+20)
                                                        </option>
                                                        <option data-countrycode="SV" value="+503">El Salvador (+503)
                                                        </option>
                                                        <option data-countrycode="GQ" value="+240">Equatorial Guinea
                                                            (+240)</option>
                                                        <option data-countrycode="ER" value="+291">Eritrea (+291)
                                                        </option>
                                                        <option data-countrycode="EE" value="+372">Estonia (+372)
                                                        </option>
                                                        <option data-countrycode="ET" value="+251">Ethiopia (+251)
                                                        </option>
                                                        <option data-countrycode="FK" value="+500">Falkland Islands
                                                            (+500)</option>
                                                        <option data-countrycode="FO" value="+298">Faroe Islands
                                                            (+298)</option>
                                                        <option data-countrycode="FJ" value="+679">Fiji (+679)
                                                        </option>
                                                        <option data-countrycode="FI" value="+358">Finland (+358)
                                                        </option>
                                                        <option data-countrycode="FR" value="+33">France (+33)
                                                        </option>
                                                        <option data-countrycode="GF" value="+594">French Guiana
                                                            (+594)</option>
                                                        <option data-countrycode="PF" value="+689">French Polynesia
                                                            (+689)</option>
                                                        <option data-countrycode="GA" value="+241">Gabon (+241)
                                                        </option>
                                                        <option data-countrycode="GM" value="+220">Gambia (+220)
                                                        </option>
                                                        <option data-countrycode="GE" value="+7880">Georgia (+7880)
                                                        </option>
                                                        <option data-countrycode="DE" value="+49">Germany (+49)
                                                        </option>
                                                        <option data-countrycode="GH" value="+233">Ghana (+233)
                                                        </option>
                                                        <option data-countrycode="GI" value="+350">Gibraltar (+350)
                                                        </option>
                                                        <option data-countrycode="GR" value="+30">Greece (+30)
                                                        </option>
                                                        <option data-countrycode="GL" value="+299">Greenland (+299)
                                                        </option>
                                                        <option data-countrycode="GD" value="+1473">Grenada (+1473)
                                                        </option>
                                                        <option data-countrycode="GP" value="+590">Guadeloupe (+590)
                                                        </option>
                                                        <option data-countrycode="GU" value="+671">Guam (+671)
                                                        </option>
                                                        <option data-countrycode="GT" value="+502">Guatemala (+502)
                                                        </option>
                                                        <option data-countrycode="GN" value="+224">Guinea (+224)
                                                        </option>
                                                        <option data-countrycode="GW" value="+245">Guinea - Bissau
                                                            (+245)</option>
                                                        <option data-countrycode="GY" value="+592">Guyana (+592)
                                                        </option>
                                                        <option data-countrycode="HT" value="+509">Haiti (+509)
                                                        </option>
                                                        <option data-countrycode="HN" value="+504">Honduras (+504)
                                                        </option>
                                                        <option data-countrycode="HK" value="+852">Hong Kong (+852)
                                                        </option>
                                                        <option data-countrycode="HU" value="+36">Hungary (+36)
                                                        </option>
                                                        <option data-countrycode="IS" value="+354">Iceland (+354)
                                                        </option>
                                                        <option data-countrycode="ID" value="+62">Indonesia (+62)

                                                        <option data-countrycode="IN" value="+91">India (+91)
                                                        </option>
                                                        </option>
                                                        <option data-countrycode="IR" value="+98">Iran (+98)</option>
                                                        <option data-countrycode="IQ" value="+964">Iraq (+964)
                                                        </option>
                                                        <option data-countrycode="IE" value="+353">Ireland (+353)
                                                        </option>
                                                        <option data-countrycode="IL" value="+972">Israel (+972)
                                                        </option>
                                                        <option data-countrycode="IT" value="+39">Italy (+39)
                                                        </option>
                                                        <option data-countrycode="JM" value="+1876">Jamaica (+1876)
                                                        </option>
                                                        <option data-countrycode="JP" value="+81">Japan (+81)
                                                        </option>
                                                        <option data-countrycode="JO" value="+962">Jordan (+962)
                                                        </option>
                                                        <option data-countrycode="KZ" value="+7">Kazakhstan (+7)
                                                        </option>
                                                        <option data-countrycode="KE" value="+254">Kenya (+254)
                                                        </option>
                                                        <option data-countrycode="KI" value="+686">Kiribati (+686)
                                                        </option>
                                                        <option data-countrycode="KP" value="+850">Korea North (+850)
                                                        </option>
                                                        <option data-countrycode="KR" value="+82">Korea South (+82)
                                                        </option>
                                                        <option data-countrycode="KW" value="+965">Kuwait (+965)
                                                        </option>
                                                        <option data-countrycode="KG" value="+996">Kyrgyzstan (+996)
                                                        </option>
                                                        <option data-countrycode="LA" value="+856">Laos (+856)
                                                        </option>
                                                        <option data-countrycode="LV" value="+371">Latvia (+371)
                                                        </option>
                                                        <option data-countrycode="LB" value="+961">Lebanon (+961)
                                                        </option>
                                                        <option data-countrycode="LS" value="+266">Lesotho (+266)
                                                        </option>
                                                        <option data-countrycode="LR" value="+231">Liberia (+231)
                                                        </option>
                                                        <option data-countrycode="LY" value="+218">Libya (+218)
                                                        </option>
                                                        <option data-countrycode="LI" value="+417">Liechtenstein
                                                            (+417)</option>
                                                        <option data-countrycode="LT" value="+370">Lithuania (+370)
                                                        </option>
                                                        <option data-countrycode="LU" value="+352">Luxembourg (+352)
                                                        </option>
                                                        <option data-countrycode="MO" value="+853">Macao (+853)
                                                        </option>
                                                        <option data-countrycode="MK" value="+389">Macedonia (+389)
                                                        </option>
                                                        <option data-countrycode="MG" value="+261">Madagascar (+261)
                                                        </option>
                                                        <option data-countrycode="MW" value="+265">Malawi (+265)
                                                        </option>
                                                        <option data-countrycode="MY" value="+60">Malaysia (+60)
                                                        </option>
                                                        <option data-countrycode="MV" value="+960">Maldives (+960)
                                                        </option>
                                                        <option data-countrycode="ML" value="+223">Mali (+223)
                                                        </option>
                                                        <option data-countrycode="MT" value="+356">Malta (+356)
                                                        </option>
                                                        <option data-countrycode="MH" value="+692">Marshall Islands
                                                            (+692)</option>
                                                        <option data-countrycode="MQ" value="+596">Martinique (+596)
                                                        </option>
                                                        <option data-countrycode="MR" value="+222">Mauritania (+222)
                                                        </option>
                                                        <option data-countrycode="YT" value="+269">Mayotte (+269)
                                                        </option>
                                                        <option data-countrycode="MX" value="+52">Mexico (+52)
                                                        </option>
                                                        <option data-countrycode="FM" value="+691">Micronesia (+691)
                                                        </option>
                                                        <option data-countrycode="MD" value="+373">Moldova (+373)
                                                        </option>
                                                        <option data-countrycode="MC" value="+377">Monaco (+377)
                                                        </option>
                                                        <option data-countrycode="MN" value="+976">Mongolia (+976)
                                                        </option>
                                                        <option data-countrycode="MS" value="+1664">Montserrat
                                                            (+1664)</option>
                                                        <option data-countrycode="MA" value="+212">Morocco (+212)
                                                        </option>
                                                        <option data-countrycode="MZ" value="+258">Mozambique (+258)
                                                        </option>
                                                        <option data-countrycode="MN" value="+95">Myanmar (+95)
                                                        </option>
                                                        <option data-countrycode="NA" value="+264">Namibia (+264)
                                                        </option>
                                                        <option data-countrycode="NR" value="+674">Nauru (+674)
                                                        </option>
                                                        <option data-countrycode="NP" value="+977">Nepal (+977)
                                                        </option>
                                                        <option data-countrycode="NL" value="+31">Netherlands (+31)
                                                        </option>
                                                        <option data-countrycode="NC" value="+687">New Caledonia
                                                            (+687)</option>
                                                        <option data-countrycode="NZ" value="+64">New Zealand (+64)
                                                        </option>
                                                        <option data-countrycode="NI" value="+505">Nicaragua (+505)
                                                        </option>
                                                        <option data-countrycode="NE" value="+227">Niger (+227)
                                                        </option>
                                                        <option data-countrycode="NG" value="+234">Nigeria (+234)
                                                        </option>
                                                        <option data-countrycode="NU" value="+683">Niue (+683)
                                                        </option>
                                                        <option data-countrycode="NF" value="+672">Norfolk Islands
                                                            (+672)</option>
                                                        <option data-countrycode="NP" value="+670">Northern Marianas
                                                            (+670)</option>
                                                        <option data-countrycode="NO" value="+47">Norway (+47)
                                                        </option>
                                                        <option data-countrycode="OM" value="+968">Oman (+968)
                                                        </option>
                                                        <option data-countrycode="PW" value="+680">Palau (+680)
                                                        </option>
                                                        <option data-countrycode="PA" value="+507">Panama (+507)
                                                        </option>
                                                        <option data-countrycode="PG" value="+675">Papua New Guinea
                                                            (+675)</option>
                                                        <option data-countrycode="PY" value="+595">Paraguay (+595)
                                                        </option>
                                                        <option data-countrycode="PE" value="+51">Peru (+51)</option>
                                                        <option data-countrycode="PH" value="+63">Philippines (+63)
                                                        </option>
                                                        <option data-countrycode="PL" value="+48">Poland (+48)
                                                        </option>
                                                        <option data-countrycode="PT" value="+351">Portugal (+351)
                                                        </option>
                                                        <option data-countrycode="PR" value="+1787">Puerto Rico
                                                            (+1787)</option>
                                                        <option data-countrycode="QA" value="+974">Qatar (+974)
                                                        </option>
                                                        <option data-countrycode="RE" value="+262">Reunion (+262)
                                                        </option>
                                                        <option data-countrycode="RO" value="+40">Romania (+40)
                                                        </option>
                                                        <option data-countrycode="RU" value="+7">Russia (+7)</option>
                                                        <option data-countrycode="RW" value="+250">Rwanda (+250)
                                                        </option>
                                                        <option data-countrycode="SM" value="+378">San Marino (+378)
                                                        </option>
                                                        <option data-countrycode="ST" value="+239">Sao Tome &amp;
                                                            Principe (+239)</option>
                                                        <option data-countrycode="SA" value="+966">Saudi Arabia
                                                            (+966)</option>
                                                        <option data-countrycode="SN" value="+221">Senegal (+221)
                                                        </option>
                                                        <option data-countrycode="CS" value="+381">Serbia (+381)
                                                        </option>
                                                        <option data-countrycode="SC" value="+248">Seychelles (+248)
                                                        </option>
                                                        <option data-countrycode="SL" value="+232">Sierra Leone
                                                            (+232)</option>
                                                        <option data-countrycode="SG" value="+65">Singapore (+65)
                                                        </option>
                                                        <option data-countrycode="SK" value="+421">Slovak Republic
                                                            (+421)</option>
                                                        <option data-countrycode="SI" value="+386">Slovenia (+386)
                                                        </option>
                                                        <option data-countrycode="SB" value="+677">Solomon Islands
                                                            (+677)</option>
                                                        <option data-countrycode="SO" value="+252">Somalia (+252)
                                                        </option>
                                                        <option data-countrycode="ZA" value="+27">South Africa (+27)
                                                        </option>
                                                        <option data-countrycode="ES" value="+34">Spain (+34)
                                                        </option>
                                                        <option data-countrycode="LK" value="+94">Sri Lanka (+94)
                                                        </option>
                                                        <option data-countrycode="SH" value="+290">St. Helena (+290)
                                                        </option>
                                                        <option data-countrycode="KN" value="+1869">St. Kitts (+1869)
                                                        </option>
                                                        <option data-countrycode="SC" value="+1758">St. Lucia (+1758)
                                                        </option>
                                                        <option data-countrycode="SD" value="+249">Sudan (+249)
                                                        </option>
                                                        <option data-countrycode="SR" value="+597">Suriname (+597)
                                                        </option>
                                                        <option data-countrycode="SZ" value="+268">Swaziland (+268)
                                                        </option>
                                                        <option data-countrycode="SE" value="+46">Sweden (+46)
                                                        </option>
                                                        <option data-countrycode="CH" value="+41">Switzerland (+41)
                                                        </option>
                                                        <option data-countrycode="SI" value="+963">Syria (+963)
                                                        </option>
                                                        <option data-countrycode="TW" value="+886">Taiwan (+886)
                                                        </option>
                                                        <option data-countrycode="TJ" value="+7">Tajikstan (+7)
                                                        </option>
                                                        <option data-countrycode="TH" value="+66">Thailand (+66)
                                                        </option>
                                                        <option data-countrycode="TG" value="+228">Togo (+228)
                                                        </option>
                                                        <option data-countrycode="TO" value="+676">Tonga (+676)
                                                        </option>
                                                        <option data-countrycode="TN" value="+216">Tunisia (+216)
                                                        </option>
                                                        <option data-countrycode="TR" value="+90">Turkey (+90)
                                                        </option>
                                                        <option data-countrycode="TM" value="+7">Turkmenistan (+7)
                                                        </option>
                                                        <option data-countrycode="TM" value="+993">Turkmenistan
                                                            (+993)</option>
                                                        <option data-countrycode="TV" value="+688">Tuvalu (+688)
                                                        </option>
                                                        <option data-countrycode="UG" value="+256">Uganda (+256)
                                                        </option>
                                                        <option data-countrycode="GB" value="+44">UK (+44)</option>
                                                        <option data-countrycode="UA" value="+380">Ukraine (+380)
                                                        </option>

                                                        <option data-countrycode="UY" value="+598">Uruguay (+598)
                                                        </option>
                                                        <option data-countrycode="US" value="+1">USA (+1)</option>
                                                        <option data-countrycode="UZ" value="+7">Uzbekistan (+7)
                                                        </option>
                                                        <option data-countrycode="VU" value="+678">Vanuatu (+678)
                                                        </option>
                                                        <option data-countrycode="VA" value="+379">Vatican City
                                                            (+379)</option>
                                                        <option data-countrycode="VE" value="+58">Venezuela (+58)
                                                        </option>
                                                        <option data-countrycode="VN" value="+84">Vietnam (+84)
                                                        </option>
                                                        <option data-countrycode="VI" value="+84">Virgin Islands - US
                                                            (+1340)</option>
                                                        <option data-countrycode="YE" value="+969">Yemen
                                                            (North)(+969)</option>
                                                        <option data-countrycode="YE" value="+967">Yemen
                                                            (South)(+967)</option>
                                                        <option data-countrycode="ZM" value="+260">Zambia (+260)
                                                        </option>
                                                        <option data-countrycode="ZW" value="+263">Zimbabwe (+263)
                                                        </option>

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <input class="form-control" maxlength="10" minlength="10" id="phone"
                                                    name="phone" placeholder="Phone Number" type="text" required>
                                                <div id="phone-error" class="error-message"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="companyName" name="companyName"
                                            placeholder="Company Name" type="text">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="website" name="website"
                                            placeholder="Company Website" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <select class="form-control" id="companyType" name="companyType" style="height: 50px;"
                                            required>
                                            <option disabled="" selected="" value="">Select Company Type</option>
                                            <option value="General Contractor">General Contractor</option>
                                            <option value="Specialty Contractor">Specialty Contractor</option>
                                            <option value="Owner or Developer">Owner or Developer</option>
                                            <option value="Government">Government</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="city" name="city" placeholder="City"
                                            type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group comments">
                                        <textarea class="form-control" id="aboutProject" name="aboutProject"
                                            placeholder="Tell Us About Project"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-12" style="text-align:center;">
                                    <button type="submit" name="submit" id="submit" class="contact-form-button">
                                        Get a Free Demo Now
                                    </button>
                                </div>
                        </form>
                    </div>
                </div>

                <!-- Modal footer -->
                <!-- <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div> -->

            </div>
        </div>
    </div>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modernizr.custom.13711.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/count-to.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootsnav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <script>
    $(document).ready(function() {
        $('#phone').on('input', function() {
            var phoneInput = $(this).val();
            var phoneError = $('#phone-error');
            var phonePattern = /^\d{10}$/; // Regular expression for 10 digits only

            if (!phonePattern.test(phoneInput)) {
                phoneError.text('Please enter a phone number.');
            } else {
                phoneError.text('');
            }
        });
    });
    </script>


    <script>
    document.getElementById('phone').addEventListener('input', function() {
        var phoneInput = this.value;
        var phoneError = document.getElementById('phone-error');
        var phonePattern = /^\d{10}$/; // Regular expression for 10 digits only

        if (!phonePattern.test(phoneInput)) {
            phoneError.textContent = 'Please enter a valid phone number.';
        } else {
            phoneError.textContent = '';
        }
    });
    </script>

    <script>
    $(document).ready(function() {
        $("#testimonial-slider").owlCarousel({
            items: 1,
            itemsDesktop: [1000, 1],
            itemsDesktopSmall: [979, 1],
            itemsTablet: [769, 1],
            pagination: true,
            autoplay: true
        });
    });
    </script>

    <script>
    var phoneInput = document.getElementById('phone');
    var phoneError = document.getElementById('phone-error');

    phoneInput.addEventListener('input', function() {
        var inputValue = phoneInput.value;
        if (!/^\d+$/.test(inputValue)) {
            phoneError.innerHTML = 'Please enter numbers only.';
        } else {
            phoneError.innerHTML = '';
        }
    });

    function validateForm() {
        // Other form validation logic

        var phoneValue = phoneInput.value;
        if (!/^\d+$/.test(phoneValue)) {
            phoneError.innerHTML = 'Please enter numbers only.';
            return false;
        } else {
            phoneError.innerHTML = '';
        }

        // Other form validation logic

        return true; // Submit the form if all validations pass
    }
    </script>

</body>

</html><?php /**PATH C:\xampp\htdocs\CivitBUILD\civitbuild-laravel\resources\views/home-page/index.blade.php ENDPATH**/ ?>
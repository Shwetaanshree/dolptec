<!DOCTYPE html>

<html>



<head>

    <title>Admin Mail</title>

</head>

<body>

    <p>Dear Admin,</p>
    <p>We have received an enquiry through the form.</p>
    <p>Below are the details submitted from the customer.</p>
     <strong>Name:</strong> <?php echo e($fName . ' ' . $lName); ?><br>
    <strong>Email:</strong> <?php echo e($fromEmail); ?><br>
    <strong>Phone:</strong> <?php echo e($phone); ?><br>
     <strong>Designation:</strong> <?php echo e($designation); ?><br>    
     <strong>Company Type:</strong> <?php echo e($companyType); ?><br>
     <strong>Company Name:</strong> <?php echo e($companyName); ?><br>
     <strong>Website:</strong> <?php echo e($companyWebsite); ?><br>
     <strong>Country:</strong> <?php echo e($country); ?><br>
     <strong>City:</strong> <?php echo e($city); ?><br>
     <strong>About Project:</strong> <?php echo e($aboutProject); ?><br>


    <br>
    Rgds,

</body>
</html><?php /**PATH C:\xampp\htdocs\CivitBUILD\new-backup\resources\views/email-body/email-enquiry.blade.php ENDPATH**/ ?>
<img class="direct-chat-img w-40" src="dist/img/AdminLTELogo.png" alt="message user image">

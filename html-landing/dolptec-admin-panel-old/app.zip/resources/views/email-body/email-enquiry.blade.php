<!DOCTYPE html>

<html>



<head>

    <title>Admin Mail</title>

</head>

<body>

    <p>Dear Admin,</p>
    <p>We have received an enquiry through the form.</p>
    <p>Below are the details submitted from the customer.</p>
     <strong>Name:</strong> {{ $fName . ' ' . $lName }}<br>
    <strong>Email:</strong> {{ $fromEmail }}<br>
    <strong>Phone:</strong> {{ $phone }}<br>
     <strong>Designation:</strong> {{ $designation }}<br>    
     <strong>Company Type:</strong> {{ $companyType }}<br>
     <strong>Company Name:</strong> {{ $companyName }}<br>
     <strong>Website:</strong> {{ $companyWebsite }}<br>
     <strong>Country:</strong> {{ $country }}<br>
     <strong>Company Size:</strong> {{ $city }}<br>
     <strong>About Project:</strong> {{ $aboutProject }}<br>


    <br>
    Rgds,

</body>
</html>